import { useState } from 'react'
import type { Page, NavigateFn } from './types'
import HomePage from './pages/HomePage'
import ExhibitionsPage from './pages/ExhibitionsPage'
import ExhibitionDetailPage from './pages/ExhibitionDetailPage'
import ProjectDetailPage from './pages/ProjectDetailPage'
import LoginPage from './pages/LoginPage'
import DashboardPage from './pages/DashboardPage'
import SubmitProjectPage from './pages/SubmitProjectPage'
import MyProjectsPage from './pages/MyProjectsPage'
import SearchResultsPage from './pages/SearchResultsPage'
import NotFoundPage from './pages/NotFoundPage'

const DASHBOARD_PAGES: Page[] = ['dashboard', 'submit', 'my-projects', 'profile', 'notifications']

const SearchIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
  </svg>
)

interface NavProps {
  page: Page
  navigate: NavigateFn
  isLoggedIn: boolean
}

function Nav({ page, navigate, isLoggedIn }: NavProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const showSearch = !DASHBOARD_PAGES.includes(page)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) navigate('search')
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-[#dadad3]" style={{ height: 64 }}>
      <div className="max-w-[1280px] mx-auto px-6 h-full flex items-center gap-4">
        <button
          onClick={() => navigate('home')}
          className="flex items-center gap-2 shrink-0 group"
        >
          <div className="w-8 h-8 bg-[#e60023] rounded-full flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="white">
              <path d="M7 0C3.13 0 0 3.13 0 7c0 2.97 1.84 5.52 4.46 6.59-.06-.52-.12-1.33.02-1.9.13-.51.87-3.7.87-3.7s-.22-.44-.22-1.1c0-1.03.6-1.8 1.34-1.8.63 0 .94.47.94 1.04 0 .63-.4 1.58-.61 2.46-.17.73.37 1.33 1.09 1.33 1.3 0 2.31-1.38 2.31-3.37 0-1.76-1.26-2.99-3.07-2.99-2.09 0-3.31 1.57-3.31 3.19 0 .63.24 1.31.54 1.68.06.07.07.13.05.2-.06.22-.18.73-.2.83-.03.13-.1.16-.23.1-.87-.41-1.41-1.68-1.41-2.71 0-2.2 1.6-4.23 4.62-4.23 2.42 0 4.31 1.73 4.31 4.03 0 2.41-1.52 4.34-3.62 4.34-.71 0-1.37-.37-1.6-.8l-.43 1.62c-.16.6-.58 1.35-.86 1.81.65.2 1.34.31 2.05.31 3.87 0 7-3.13 7-7S10.87 0 7 0z" />
            </svg>
          </div>
          <span className="font-bold text-black text-[15px] hidden sm:block tracking-tight">ExhibitHub</span>
        </button>

        {showSearch && (
          <form onSubmit={handleSearch} className="flex-1 max-w-[480px] mx-auto hidden md:flex items-center bg-[#f6f6f3] rounded-full px-4 gap-3" style={{ height: 48 }}>
            <SearchIcon />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search exhibitions, projects, topics..."
              className="flex-1 bg-transparent text-black text-[16px] outline-none placeholder:text-[#91918c]"
            />
          </form>
        )}

        <div className="ml-auto flex items-center gap-1">
          <button
            onClick={() => navigate('exhibitions')}
            className="hidden md:block text-[14px] font-semibold text-black px-3 py-2 rounded-2xl hover:bg-[#f6f6f3] transition-colors"
          >
            Explore
          </button>
          <button className="hidden md:block text-[14px] font-semibold text-[#62625b] px-3 py-2 rounded-2xl hover:bg-[#f6f6f3] transition-colors">
            About
          </button>

          {isLoggedIn ? (
            <button
              onClick={() => navigate('dashboard')}
              className="flex items-center gap-2 ml-2"
            >
              <div className="w-8 h-8 rounded-full bg-[#e60023] flex items-center justify-center text-white text-[13px] font-bold">
                A
              </div>
            </button>
          ) : (
            <>
              <button
                onClick={() => navigate('login')}
                className="hidden md:block text-[14px] font-semibold text-black px-3 py-2 rounded-2xl hover:bg-[#f6f6f3] transition-colors"
              >
                Log in
              </button>
              <button
                onClick={() => navigate('login')}
                className="bg-[#e60023] text-white text-[14px] font-bold px-4 rounded-2xl hover:bg-[#cc001f] transition-colors"
                style={{ height: 40 }}
              >
                Sign up
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  )
}

interface DashboardShellProps {
  page: Page
  navigate: NavigateFn
  setIsLoggedIn: (v: boolean) => void
}

function DashboardShell({ page, navigate, setIsLoggedIn }: DashboardShellProps) {
  const navItems: { label: string; icon: string; page: Page }[] = [
    { label: 'Overview', icon: '⊞', page: 'dashboard' },
    { label: 'My Projects', icon: '◫', page: 'my-projects' },
    { label: 'Submit Project', icon: '+', page: 'submit' },
    { label: 'Notifications', icon: '◎', page: 'notifications' },
    { label: 'Profile', icon: '◷', page: 'profile' },
  ]

  return (
    <div className="flex min-h-screen">
      <aside className="fixed top-0 left-0 bottom-0 w-[240px] bg-[#262622] flex flex-col z-40">
        <div className="px-5 py-5 border-b border-white/10">
          <button onClick={() => navigate('home')} className="flex items-center gap-2">
            <div className="w-7 h-7 bg-[#e60023] rounded-full flex items-center justify-center">
              <svg width="12" height="12" viewBox="0 0 14 14" fill="white">
                <path d="M7 0C3.13 0 0 3.13 0 7c0 2.97 1.84 5.52 4.46 6.59-.06-.52-.12-1.33.02-1.9.13-.51.87-3.7.87-3.7s-.22-.44-.22-1.1c0-1.03.6-1.8 1.34-1.8.63 0 .94.47.94 1.04 0 .63-.4 1.58-.61 2.46-.17.73.37 1.33 1.09 1.33 1.3 0 2.31-1.38 2.31-3.37 0-1.76-1.26-2.99-3.07-2.99-2.09 0-3.31 1.57-3.31 3.19 0 .63.24 1.31.54 1.68.06.07.07.13.05.2-.06.22-.18.73-.2.83-.03.13-.1.16-.23.1-.87-.41-1.41-1.68-1.41-2.71 0-2.2 1.6-4.23 4.62-4.23 2.42 0 4.31 1.73 4.31 4.03 0 2.41-1.52 4.34-3.62 4.34-.71 0-1.37-.37-1.6-.8l-.43 1.62c-.16.6-.58 1.35-.86 1.81.65.2 1.34.31 2.05.31 3.87 0 7-3.13 7-7S10.87 0 7 0z" />
              </svg>
            </div>
            <span className="font-bold text-white text-[14px] tracking-tight">ExhibitHub</span>
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
          {navItems.map(item => (
            <button
              key={item.page}
              onClick={() => navigate(item.page)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-2xl text-[14px] font-semibold text-left transition-colors ${
                page === item.page
                  ? 'bg-white/15 text-white'
                  : 'text-white/60 hover:bg-white/8 hover:text-white/90'
              }`}
            >
              <span className="text-[16px] w-5 text-center">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="px-4 py-4 border-t border-white/10">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full bg-[#e60023] flex items-center justify-center text-white text-[12px] font-bold">
              A
            </div>
            <div>
              <p className="text-white text-[13px] font-semibold leading-tight">Ahmad Rizki</p>
              <p className="text-white/40 text-[11px]">Exhibitor</p>
            </div>
          </div>
          <button
            onClick={() => { setIsLoggedIn(false); navigate('home') }}
            className="w-full text-left text-white/40 text-[12px] hover:text-white/70 transition-colors py-1"
          >
            Sign out
          </button>
        </div>
      </aside>

      <main className="ml-[240px] flex-1 min-h-screen bg-[#fbfbf9]">
        {page === 'dashboard' && <DashboardPage navigate={navigate} />}
        {page === 'submit' && <SubmitProjectPage navigate={navigate} />}
        {page === 'my-projects' && <MyProjectsPage navigate={navigate} />}
        {page === 'notifications' && <NotificationsPage navigate={navigate} />}
        {page === 'profile' && <ProfilePage navigate={navigate} />}
      </main>
    </div>
  )
}

function NotificationsPage({ navigate: _navigate }: { navigate: NavigateFn }) {
  const notifications = [
    { id: 1, type: 'approval', title: 'Project Approved', body: 'Your project "Smart Vertical Farming System" has been approved for the Innovations in Sustainable Technology exhibition.', time: '2 hours ago', read: false },
    { id: 2, type: 'announcement', title: 'New Exhibition Open', body: 'Submissions are now open for the Data Science & AI Applications exhibition. Deadline: 15 April 2025.', time: '1 day ago', read: false },
    { id: 3, type: 'update', title: 'Exhibition Reminder', body: 'The Digital Arts & Creative Computing exhibition ends in 5 days. Make sure your project is complete.', time: '2 days ago', read: true },
    { id: 4, type: 'system', title: 'Welcome to ExhibitHub', body: 'Your account has been verified. You can now submit projects to open exhibitions.', time: '1 week ago', read: true },
  ]
  return (
    <div className="p-8 max-w-[800px]">
      <h1 className="font-display text-[32px] font-bold text-black mb-2" style={{ fontFamily: "'Fraunces', serif" }}>Notifications</h1>
      <p className="text-[#62625b] text-[14px] mb-8">You have {notifications.filter(n => !n.read).length} unread notifications.</p>
      <div className="flex flex-col gap-3">
        {notifications.map(n => (
          <div key={n.id} className={`bg-white rounded-2xl p-5 border ${n.read ? 'border-[#dadad3]' : 'border-[#e60023]/20'}`}>
            <div className="flex items-start gap-4">
              <div className={`w-2 h-2 rounded-full mt-2 shrink-0 ${n.read ? 'bg-[#dadad3]' : 'bg-[#e60023]'}`} />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[14px] font-semibold text-black">{n.title}</span>
                  <span className="text-[12px] text-[#91918c]">{n.time}</span>
                </div>
                <p className="text-[14px] text-[#62625b]">{n.body}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function ProfilePage({ navigate: _navigate }: { navigate: NavigateFn }) {
  const [name, setName] = useState('Ahmad Rizki')
  const [email, setEmail] = useState('ahmad.rizki@university.edu')
  const [bio, setBio] = useState('Computer Science student specializing in AI and IoT systems. Passionate about sustainable technology solutions.')
  const [institution, setInstitution] = useState('Universiti Teknologi Malaysia')

  return (
    <div className="p-8 max-w-[720px]">
      <h1 className="font-display text-[32px] font-bold text-black mb-2" style={{ fontFamily: "'Fraunces', serif" }}>Profile</h1>
      <p className="text-[#62625b] text-[14px] mb-8">Manage your personal information and account settings.</p>

      <div className="bg-white rounded-[32px] p-8 border border-[#dadad3] mb-6">
        <div className="flex items-center gap-6 mb-8">
          <div className="w-20 h-20 rounded-full bg-[#e60023] flex items-center justify-center text-white text-[28px] font-bold">A</div>
          <div>
            <button className="bg-[#f6f6f3] text-black text-[14px] font-semibold px-4 py-2 rounded-2xl hover:bg-[#e5e5e0] transition-colors">
              Change photo
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          {[
            { label: 'Full name', value: name, setter: setName },
            { label: 'Institution', value: institution, setter: setInstitution },
          ].map(field => (
            <div key={field.label}>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">{field.label}</label>
              <input
                value={field.value}
                onChange={e => field.setter(e.target.value)}
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-2.5 text-[14px] text-black outline-none focus:border-black transition-colors"
              />
            </div>
          ))}
        </div>

        <div className="mb-4">
          <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Email address</label>
          <input
            value={email}
            onChange={e => setEmail(e.target.value)}
            className="w-full border border-[#dadad3] rounded-2xl px-4 py-2.5 text-[14px] text-black outline-none focus:border-black transition-colors"
          />
        </div>

        <div className="mb-6">
          <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Bio</label>
          <textarea
            value={bio}
            onChange={e => setBio(e.target.value)}
            rows={3}
            className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[14px] text-black outline-none focus:border-black transition-colors resize-none"
          />
        </div>

        <button className="bg-[#e60023] text-white text-[14px] font-bold px-6 py-2.5 rounded-2xl hover:bg-[#cc001f] transition-colors">
          Save changes
        </button>
      </div>

      <div className="bg-white rounded-[32px] p-8 border border-[#dadad3]">
        <h2 className="text-[18px] font-semibold text-black mb-4">Change password</h2>
        <div className="flex flex-col gap-3 mb-4">
          {['Current password', 'New password', 'Confirm new password'].map(label => (
            <div key={label}>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">{label}</label>
              <input
                type="password"
                placeholder="••••••••"
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-2.5 text-[14px] text-black outline-none focus:border-black transition-colors"
              />
            </div>
          ))}
        </div>
        <button className="bg-[#f6f6f3] text-black text-[14px] font-bold px-6 py-2.5 rounded-2xl hover:bg-[#e5e5e0] transition-colors">
          Update password
        </button>
      </div>
    </div>
  )
}

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  const navigate: NavigateFn = (p) => {
    setPage(p)
    window.scrollTo({ top: 0 })
  }

  const isDashboard = DASHBOARD_PAGES.includes(page)

  return (
    <div className="min-h-screen bg-[#fbfbf9]">
      {!isDashboard && (
        <Nav page={page} navigate={navigate} isLoggedIn={isLoggedIn} />
      )}

      {page === 'home' && <HomePage navigate={navigate} />}
      {page === 'exhibitions' && <ExhibitionsPage navigate={navigate} />}
      {page === 'exhibition-detail' && <ExhibitionDetailPage navigate={navigate} />}
      {page === 'project-detail' && <ProjectDetailPage navigate={navigate} />}
      {page === 'search' && <SearchResultsPage navigate={navigate} />}
      {page === 'not-found' && <NotFoundPage navigate={navigate} />}
      {page === 'login' && (
        <LoginPage
          navigate={navigate}
          onLoginSuccess={() => { setIsLoggedIn(true); navigate('dashboard') }}
        />
      )}
      {isDashboard && (
        <DashboardShell page={page} navigate={navigate} setIsLoggedIn={setIsLoggedIn} />
      )}
    </div>
  )
}
