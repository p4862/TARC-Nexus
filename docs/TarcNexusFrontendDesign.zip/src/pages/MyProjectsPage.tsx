import { useState } from 'react'
import type { NavigateFn } from '../types'

const PROJECTS = [
  {
    id: 1,
    title: "Smart Vertical Farming System with IoT-Driven Microclimate Control",
    exhibition: "Innovations in Sustainable Technology",
    category: "Technology",
    status: "Approved",
    updated: "2 Apr 2025",
    views: 1284,
    downloads: 47,
    image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=400&h=300&fit=crop&auto=format",
  },
  {
    id: 2,
    title: "AI-Powered Sign Language Translator for Deaf and Hard-of-Hearing Communities",
    exhibition: "Data Science & AI Applications",
    category: "Technology",
    status: "Pending Review",
    updated: "28 Mar 2025",
    views: 0,
    downloads: 0,
    image: "https://images.unsplash.com/photo-1767244489692-a047c63a463e?w=400&h=300&fit=crop&auto=format",
  },
  {
    id: 3,
    title: "Modular Earthquake-Resistant Housing System for High-Risk Urban Areas",
    exhibition: "Architecture & Urban Design 2025",
    category: "Architecture",
    status: "Draft",
    updated: "21 Mar 2025",
    views: 0,
    downloads: 0,
    image: "https://images.unsplash.com/photo-1655668135850-5eef0ba21f24?w=400&h=300&fit=crop&auto=format",
  },
]

const FILTERS = ['All', 'Draft', 'Pending Review', 'Approved', 'Rejected']

const STATUS_STYLES: Record<string, string> = {
  Approved: 'bg-emerald-50 text-emerald-700',
  'Pending Review': 'bg-amber-50 text-amber-700',
  Draft: 'bg-[#f6f6f3] text-[#62625b]',
  Rejected: 'bg-red-50 text-red-700',
}

function DeleteModal({ title, onConfirm, onCancel }: { title: string; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
      <div className="absolute inset-0 bg-black/50" onClick={onCancel} />
      <div className="relative bg-white rounded-[32px] p-8 max-w-[420px] w-full shadow-2xl">
        <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-5">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#e60023" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
          </svg>
        </div>
        <h3 className="text-[18px] font-bold text-black text-center mb-2">Delete Project?</h3>
        <p className="text-[14px] text-[#62625b] text-center mb-6 leading-relaxed">
          "<span className="font-medium text-black">{title.slice(0, 60)}{title.length > 60 ? '…' : ''}</span>" will be permanently deleted. This cannot be undone.
        </p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 bg-[#f6f6f3] text-black text-[14px] font-bold py-3 rounded-2xl hover:bg-[#e5e5e0] transition-colors">
            Cancel
          </button>
          <button onClick={onConfirm} className="flex-1 bg-[#e60023] text-white text-[14px] font-bold py-3 rounded-2xl hover:bg-[#cc001f] transition-colors">
            Delete
          </button>
        </div>
      </div>
    </div>
  )
}

export default function MyProjectsPage({ navigate }: { navigate: NavigateFn }) {
  const [filter, setFilter] = useState('All')
  const [projects, setProjects] = useState(PROJECTS)
  const [deletingId, setDeletingId] = useState<number | null>(null)
  const [view, setView] = useState<'grid' | 'list'>('grid')

  const visible = filter === 'All' ? projects : projects.filter(p => p.status === filter)
  const counts = FILTERS.reduce<Record<string, number>>((acc, f) => {
    acc[f] = f === 'All' ? projects.length : projects.filter(p => p.status === f).length
    return acc
  }, {})

  const confirmDelete = () => {
    if (deletingId !== null) {
      setProjects(p => p.filter(pr => pr.id !== deletingId))
      setDeletingId(null)
    }
  }

  const deletingProject = projects.find(p => p.id === deletingId)

  return (
    <div className="p-8">
      {deletingProject && (
        <DeleteModal
          title={deletingProject.title}
          onConfirm={confirmDelete}
          onCancel={() => setDeletingId(null)}
        />
      )}

      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <p className="text-[#e60023] text-[12px] font-bold tracking-widest uppercase mb-1">My Work</p>
          <h1
            className="text-black font-bold"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(26px, 3vw, 34px)', letterSpacing: '-0.8px' }}
          >
            My Projects
          </h1>
          <p className="text-[#62625b] text-[14px] mt-1">{projects.length} project{projects.length !== 1 ? 's' : ''} total</p>
        </div>
        <button
          onClick={() => navigate('submit')}
          className="bg-[#e60023] text-white text-[14px] font-bold px-5 py-2.5 rounded-2xl hover:bg-[#cc001f] transition-colors flex items-center gap-2"
        >
          <span className="text-[18px] leading-none">+</span>
          New Project
        </button>
      </div>

      {/* Filters + view toggle */}
      <div className="flex items-center justify-between gap-4 mb-6 flex-wrap">
        <div className="flex items-center gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
          {FILTERS.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`whitespace-nowrap flex items-center gap-1.5 text-[14px] font-semibold px-4 py-2 rounded-full transition-colors ${
                filter === f ? 'bg-black text-white' : 'bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]'
              }`}
            >
              {f}
              {counts[f] > 0 && (
                <span className={`text-[11px] font-bold w-4 h-4 rounded-full flex items-center justify-center ${
                  filter === f ? 'bg-white/20 text-white' : 'bg-[#dadad3] text-[#62625b]'
                }`}>
                  {counts[f]}
                </span>
              )}
            </button>
          ))}
        </div>
        <div className="flex items-center bg-[#f6f6f3] rounded-full p-1">
          {(['grid', 'list'] as const).map(v => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-3 py-1.5 rounded-full text-[13px] font-semibold transition-colors ${
                view === v ? 'bg-white text-black shadow-sm' : 'text-[#62625b]'
              }`}
            >
              {v === 'grid' ? '⊞ Grid' : '☰ List'}
            </button>
          ))}
        </div>
      </div>

      {/* Empty state */}
      {visible.length === 0 && (
        <div className="text-center py-24 bg-white rounded-2xl border border-[#dadad3]">
          <div className="w-16 h-16 bg-[#f6f6f3] rounded-full flex items-center justify-center mx-auto mb-4">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" /><polyline points="14 2 14 8 20 8" />
            </svg>
          </div>
          <h3 className="text-[18px] font-semibold text-black mb-2">No {filter !== 'All' ? filter.toLowerCase() : ''} projects</h3>
          <p className="text-[14px] text-[#62625b] mb-6">
            {filter === 'All' ? "You haven't submitted any projects yet." : `You have no projects with status "${filter}".`}
          </p>
          {filter === 'All' && (
            <button
              onClick={() => navigate('submit')}
              className="bg-[#e60023] text-white text-[14px] font-bold px-6 py-3 rounded-2xl hover:bg-[#cc001f] transition-colors"
            >
              Submit your first project
            </button>
          )}
        </div>
      )}

      {/* Grid view */}
      {view === 'grid' && visible.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {visible.map(project => (
            <div key={project.id} className="bg-white rounded-2xl border border-[#dadad3] overflow-hidden group">
              <div className="relative overflow-hidden bg-[#f6f6f3]" style={{ height: 180 }}>
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3">
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${STATUS_STYLES[project.status]}`}>
                    {project.status}
                  </span>
                </div>
                {project.status === 'Draft' && (
                  <div className="absolute top-3 right-3 bg-amber-400 text-black text-[10px] font-bold px-2 py-0.5 rounded-full">
                    DRAFT
                  </div>
                )}
              </div>

              <div className="p-5">
                <h3 className="text-[14px] font-semibold text-black line-clamp-2 mb-1.5">{project.title}</h3>
                <p className="text-[12px] text-[#62625b] mb-1">{project.exhibition}</p>
                <p className="text-[11px] text-[#91918c] mb-4">Updated {project.updated}</p>

                {project.views > 0 && (
                  <div className="flex items-center gap-3 mb-4 text-[12px] text-[#62625b]">
                    <span>👁 {project.views.toLocaleString()} views</span>
                    <span>⬇ {project.downloads} downloads</span>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => navigate('project-detail')}
                    className="flex-1 text-center text-[13px] font-semibold text-[#62625b] bg-[#f6f6f3] px-3 py-2 rounded-2xl hover:bg-[#e5e5e0] transition-colors"
                  >
                    View
                  </button>
                  <button
                    onClick={() => navigate('submit')}
                    className="flex-1 text-center text-[13px] font-semibold text-black bg-[#f6f6f3] px-3 py-2 rounded-2xl hover:bg-[#e5e5e0] transition-colors"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => setDeletingId(project.id)}
                    className="w-9 h-9 flex items-center justify-center text-[#91918c] bg-[#f6f6f3] rounded-2xl hover:bg-red-50 hover:text-[#e60023] transition-colors"
                  >
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* List view */}
      {view === 'list' && visible.length > 0 && (
        <div className="bg-white rounded-2xl border border-[#dadad3] overflow-hidden">
          <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-4 px-5 py-3 border-b border-[#dadad3] bg-[#fbfbf9]">
            {['', 'Project', 'Status', 'Updated', 'Actions'].map(h => (
              <span key={h} className="text-[11px] font-bold text-[#91918c] uppercase tracking-wide">{h}</span>
            ))}
          </div>
          {visible.map((project, i) => (
            <div
              key={project.id}
              className={`grid grid-cols-[auto_1fr_auto_auto_auto] gap-4 px-5 py-4 items-center hover:bg-[#fbfbf9] transition-colors ${
                i < visible.length - 1 ? 'border-b border-[#dadad3]' : ''
              }`}
            >
              <div className="w-12 h-12 rounded-2xl overflow-hidden bg-[#f6f6f3] shrink-0">
                <img src={project.image} alt="" className="w-full h-full object-cover" />
              </div>
              <div className="min-w-0">
                <p className="text-[14px] font-semibold text-black line-clamp-1">{project.title}</p>
                <p className="text-[12px] text-[#62625b] mt-0.5">{project.exhibition}</p>
              </div>
              <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full whitespace-nowrap ${STATUS_STYLES[project.status]}`}>
                {project.status}
              </span>
              <span className="text-[12px] text-[#91918c] whitespace-nowrap">{project.updated}</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('project-detail')}
                  className="text-[12px] font-semibold text-[#62625b] bg-[#f6f6f3] px-3 py-1.5 rounded-full hover:bg-[#e5e5e0] transition-colors whitespace-nowrap"
                >
                  View
                </button>
                <button
                  onClick={() => navigate('submit')}
                  className="text-[12px] font-semibold text-black bg-[#f6f6f3] px-3 py-1.5 rounded-full hover:bg-[#e5e5e0] transition-colors"
                >
                  Edit
                </button>
                <button
                  onClick={() => setDeletingId(project.id)}
                  className="text-[#91918c] hover:text-[#e60023] transition-colors p-1"
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
