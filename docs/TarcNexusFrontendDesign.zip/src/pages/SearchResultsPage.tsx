import { useState } from 'react'
import type { NavigateFn } from '../types'

const ALL_RESULTS = [
  { type: 'project' as const, title: 'Smart Vertical Farming System with IoT-Driven Microclimate Control', subtitle: 'Ahmad Rizki · Innovations in Sustainable Technology', category: 'Technology', image: 'https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=400&h=280&fit=crop&auto=format' },
  { type: 'project' as const, title: 'AI-Powered Sign Language Translator for Deaf Communities', subtitle: 'Nurul Hana · Data Science & AI Applications', category: 'Technology', image: 'https://images.unsplash.com/photo-1767244489692-a047c63a463e?w=400&h=280&fit=crop&auto=format' },
  { type: 'exhibition' as const, title: 'Innovations in Sustainable Technology', subtitle: 'Faculty of Engineering · UTM · 24 projects · Active', category: 'Exhibition', image: 'https://images.unsplash.com/photo-1768655317930-23e7cd2d336e?w=400&h=280&fit=crop&auto=format' },
  { type: 'project' as const, title: 'Real-time Urban Air Quality Monitor with Predictive Alerts', subtitle: 'Tan Jia Wei · Innovations in Sustainable Technology', category: 'Environmental IoT', image: 'https://images.unsplash.com/photo-1646756089735-487709743361?w=400&h=280&fit=crop&auto=format' },
  { type: 'exhibition' as const, title: 'Data Science & AI Applications', subtitle: 'Faculty of Computing · UPM · 28 projects · Active', category: 'Exhibition', image: 'https://images.unsplash.com/photo-1769913775153-0468a774d9ff?w=400&h=280&fit=crop&auto=format' },
  { type: 'project' as const, title: 'Mycelium Composite Construction Material', subtitle: 'Mei Ling Tan · Innovations in Sustainable Technology', category: 'Green Manufacturing', image: 'https://images.unsplash.com/photo-1655668135850-5eef0ba21f24?w=400&h=280&fit=crop&auto=format' },
  { type: 'project' as const, title: 'Neural Interface for Motor Rehabilitation', subtitle: 'Priya Sharma · Biomedical Research Showcase', category: 'Biomedical AI', image: 'https://images.unsplash.com/photo-1582719299076-dd3f6f970dd4?w=400&h=280&fit=crop&auto=format' },
  { type: 'project' as const, title: 'Decentralised Peer-to-Peer Energy Trading Grid', subtitle: 'Ravi Kumar · Innovations in Sustainable Technology', category: 'Clean Energy', image: 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=400&h=280&fit=crop&auto=format' },
]

const SORT_OPTIONS = ['Most Relevant', 'Newest', 'Most Viewed', 'Alphabetical']
const TYPE_FILTERS = ['All', 'Projects', 'Exhibitions']
const CATEGORY_FILTERS = ['All Categories', 'Technology', 'Science', 'Arts', 'Engineering', 'Architecture', 'Business']

export default function SearchResultsPage({ navigate, initialQuery }: { navigate: NavigateFn; initialQuery?: string }) {
  const [query, setQuery] = useState(initialQuery ?? 'sustainable')
  const [typeFilter, setTypeFilter] = useState('All')
  const [categoryFilter, setCategoryFilter] = useState('All Categories')
  const [sort, setSort] = useState('Most Relevant')

  const results = ALL_RESULTS.filter(r => {
    const matchType = typeFilter === 'All'
      || (typeFilter === 'Projects' && r.type === 'project')
      || (typeFilter === 'Exhibitions' && r.type === 'exhibition')
    const matchCat = categoryFilter === 'All Categories' || r.category === categoryFilter || r.type === 'exhibition'
    const matchQ = !query || r.title.toLowerCase().includes(query.toLowerCase()) || r.subtitle.toLowerCase().includes(query.toLowerCase())
    return matchType && matchCat && matchQ
  })

  return (
    <div className="pt-16">
      {/* Search strip */}
      <section className="bg-white border-b border-[#dadad3] py-6">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="flex items-center bg-[#f6f6f3] rounded-full px-5 gap-3 max-w-[640px]" style={{ height: 52 }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              autoFocus
              className="flex-1 bg-transparent text-[16px] text-black outline-none placeholder:text-[#91918c]"
              placeholder="Search exhibitions, projects, topics..."
            />
            {query && (
              <button onClick={() => setQuery('')} className="text-[#91918c] hover:text-black transition-colors text-[20px] leading-none">×</button>
            )}
          </div>
        </div>
      </section>

      {/* Filter bar */}
      <section className="bg-white border-b border-[#dadad3] py-3 sticky top-16 z-30">
        <div className="max-w-[1280px] mx-auto px-6 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            {/* Type toggle */}
            <div className="flex items-center bg-[#f6f6f3] rounded-full p-1">
              {TYPE_FILTERS.map(f => (
                <button
                  key={f}
                  onClick={() => setTypeFilter(f)}
                  className={`text-[13px] font-semibold px-4 py-1.5 rounded-full transition-colors ${
                    typeFilter === f ? 'bg-white text-black shadow-sm' : 'text-[#62625b] hover:text-black'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            {/* Category chips */}
            <div className="hidden md:flex items-center gap-2 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
              {CATEGORY_FILTERS.map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`whitespace-nowrap text-[13px] font-semibold px-3 py-2 rounded-full transition-colors ${
                    categoryFilter === cat ? 'bg-black text-white' : 'bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <select
            value={sort}
            onChange={e => setSort(e.target.value)}
            className="shrink-0 text-[13px] font-semibold text-black bg-[#f6f6f3] border-none rounded-full px-4 py-2 outline-none cursor-pointer"
          >
            {SORT_OPTIONS.map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
      </section>

      {/* Results */}
      <section className="py-8 max-w-[1280px] mx-auto px-6">
        {/* Result count */}
        <p className="text-[13px] text-[#62625b] mb-6 font-medium">
          {results.length === 0
            ? `No results for "${query}"`
            : `${results.length} result${results.length !== 1 ? 's' : ''} for "${query}"`}
        </p>

        {/* Empty state */}
        {results.length === 0 && (
          <div className="text-center py-24 bg-white rounded-2xl border border-[#dadad3]">
            <div className="w-16 h-16 bg-[#f6f6f3] rounded-full flex items-center justify-center mx-auto mb-5">
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
            </div>
            <h2
              className="text-black font-bold mb-3"
              style={{ fontFamily: "'Fraunces', serif", fontSize: 24, letterSpacing: '-0.5px' }}
            >
              No results found
            </h2>
            <p className="text-[14px] text-[#62625b] mb-6 max-w-[360px] mx-auto leading-relaxed">
              We couldn't find anything matching <strong>"{query}"</strong>. Try a different search term or browse all exhibitions.
            </p>
            <div className="flex gap-3 justify-center">
              <button onClick={() => setQuery('')} className="bg-[#f6f6f3] text-black text-[14px] font-bold px-5 py-2.5 rounded-2xl hover:bg-[#e5e5e0] transition-colors">
                Clear search
              </button>
              <button onClick={() => navigate('exhibitions')} className="bg-[#e60023] text-white text-[14px] font-bold px-5 py-2.5 rounded-2xl hover:bg-[#cc001f] transition-colors">
                Browse exhibitions
              </button>
            </div>
          </div>
        )}

        {/* Results grid */}
        {results.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {results.map((result, i) => (
              <button
                key={i}
                onClick={() => navigate(result.type === 'exhibition' ? 'exhibition-detail' : 'project-detail')}
                className="bg-white rounded-2xl overflow-hidden text-left border border-[#dadad3] hover:border-[#c8c8c1] hover:shadow-sm transition-all group"
              >
                <div className="relative overflow-hidden bg-[#f6f6f3]" style={{ height: 168 }}>
                  <img
                    src={result.image}
                    alt={result.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${
                      result.type === 'exhibition'
                        ? 'bg-blue-50 text-blue-700'
                        : 'bg-white/90 backdrop-blur-sm text-black'
                    }`}>
                      {result.type === 'exhibition' ? 'Exhibition' : result.category}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-[13px] font-semibold text-black line-clamp-2 mb-1">{result.title}</h3>
                  <p className="text-[11px] text-[#62625b] line-clamp-1">{result.subtitle}</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
