import { useState } from 'react'
import type { NavigateFn } from '../types'

const EXHIBITIONS = [
  { id: 1, title: "Innovations in Sustainable Technology", faculty: "Faculty of Engineering", university: "UTM", dates: "15 Mar – 30 Apr 2025", projects: 24, status: "Active", category: "Technology", image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=600&h=360&fit=crop&auto=format", desc: "Showcasing cutting-edge solutions to the world's most pressing environmental and energy challenges." },
  { id: 2, title: "Digital Arts & Creative Computing", faculty: "School of Design", university: "NTU", dates: "1 Feb – 28 Feb 2025", projects: 18, status: "Active", category: "Arts", image: "https://images.unsplash.com/photo-1769913775153-0468a774d9ff?w=600&h=360&fit=crop&auto=format", desc: "Where computation meets creative expression — interactive installations, generative art, and digital sculptures." },
  { id: 3, title: "Biomedical Research Showcase", faculty: "Faculty of Medicine", university: "UM", dates: "10 Jan – 10 Feb 2025", projects: 31, status: "Past", category: "Science", image: "https://images.unsplash.com/photo-1582719299076-dd3f6f970dd4?w=600&h=360&fit=crop&auto=format", desc: "Groundbreaking student research in diagnostics, therapeutics, and medical device innovation." },
  { id: 4, title: "Architecture & Urban Design 2025", faculty: "School of Architecture", university: "USM", dates: "5 May – 20 May 2025", projects: 12, status: "Upcoming", category: "Architecture", image: "https://images.unsplash.com/photo-1655668135850-5eef0ba21f24?w=600&h=360&fit=crop&auto=format", desc: "Reimagining urban spaces for the next generation — sustainable cities, adaptive reuse, and speculative futures." },
  { id: 5, title: "Data Science & AI Applications", faculty: "Faculty of Computing", university: "UPM", dates: "1 Apr – 30 Apr 2025", projects: 28, status: "Active", category: "Technology", image: "https://images.unsplash.com/photo-1768655317930-23e7cd2d336e?w=600&h=360&fit=crop&auto=format", desc: "Applied machine learning, NLP, and data-driven insights tackling real-world problems." },
  { id: 6, title: "Social Innovation Challenge", faculty: "Business School", university: "UKM", dates: "15 Apr – 15 May 2025", projects: 20, status: "Upcoming", category: "Business", image: "https://images.unsplash.com/photo-1586868538513-51335a0c5337?w=600&h=360&fit=crop&auto=format", desc: "Business models and community initiatives designed to create measurable social impact." },
  { id: 7, title: "Mechatronics & Robotics Expo", faculty: "Faculty of Mechanical Engineering", university: "UiTM", dates: "20 Mar – 5 Apr 2025", projects: 16, status: "Active", category: "Engineering", image: "https://images.unsplash.com/photo-1581094271901-8022df4466f9?w=600&h=360&fit=crop&auto=format", desc: "Autonomous systems, industrial robots, and smart manufacturing solutions by the next generation of engineers." },
  { id: 8, title: "Environmental Science Congress", faculty: "Faculty of Environmental Studies", university: "UNIMAS", dates: "1 Jun – 30 Jun 2025", projects: 22, status: "Upcoming", category: "Science", image: "https://images.unsplash.com/photo-1764693948373-9e8aec06222f?w=600&h=360&fit=crop&auto=format", desc: "Research on biodiversity, climate change, and ecosystem conservation from across Southeast Asia." },
  { id: 9, title: "Information Security Symposium", faculty: "Faculty of Computing", university: "MMU", dates: "1 Jan – 28 Feb 2025", projects: 14, status: "Past", category: "Technology", image: "https://images.unsplash.com/photo-1767244489692-a047c63a463e?w=600&h=360&fit=crop&auto=format", desc: "Cybersecurity research covering penetration testing, cryptography, and zero-trust architecture." },
]

const CATEGORIES = ["All", "Technology", "Design", "Science", "Arts", "Engineering", "Business", "Architecture"]
const SORT_OPTIONS = ["Newest", "Most Projects", "Ending Soon", "Alphabetical"]

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    Active: 'bg-emerald-50 text-emerald-700',
    Upcoming: 'bg-blue-50 text-blue-700',
    Past: 'bg-[#f6f6f3] text-[#62625b]',
  }
  return (
    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${map[status] ?? map.Past}`}>
      {status}
    </span>
  )
}

export default function ExhibitionsPage({ navigate }: { navigate: NavigateFn }) {
  const [query, setQuery] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [sort, setSort] = useState('Newest')
  const [currentPage, setCurrentPage] = useState(1)

  const filtered = EXHIBITIONS.filter(ex => {
    const matchCat = activeCategory === 'All' || ex.category === activeCategory
    const matchQ = !query || ex.title.toLowerCase().includes(query.toLowerCase()) || ex.faculty.toLowerCase().includes(query.toLowerCase())
    return matchCat && matchQ
  })

  const perPage = 6
  const totalPages = Math.ceil(filtered.length / perPage)
  const visible = filtered.slice((currentPage - 1) * perPage, currentPage * perPage)

  return (
    <div className="pt-16">
      {/* Page hero strip */}
      <section className="bg-white border-b border-[#dadad3] py-10">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end gap-6">
            <div className="flex-1">
              <p className="text-[#e60023] text-[12px] font-bold tracking-widest uppercase mb-2">Browse All</p>
              <h1
                className="text-black font-bold"
                style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(32px, 4vw, 48px)', letterSpacing: '-1px' }}
              >
                Exhibitions
              </h1>
              <p className="text-[#62625b] text-[15px] mt-2">{EXHIBITIONS.length} exhibitions across {new Set(EXHIBITIONS.map(e => e.university)).size} universities</p>
            </div>

            {/* Search */}
            <div className="flex items-center bg-[#f6f6f3] rounded-full px-4 gap-3 md:w-[400px]" style={{ height: 48 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
              <input
                value={query}
                onChange={e => { setQuery(e.target.value); setCurrentPage(1) }}
                placeholder="Search exhibitions..."
                className="flex-1 bg-transparent text-[15px] text-black outline-none placeholder:text-[#91918c]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Filters + Sort */}
      <section className="bg-white border-b border-[#dadad3] py-3 sticky top-16 z-30">
        <div className="max-w-[1280px] mx-auto px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => { setActiveCategory(cat); setCurrentPage(1) }}
                className={`whitespace-nowrap text-[14px] font-semibold px-4 py-2 rounded-full transition-colors ${
                  activeCategory === cat ? 'bg-black text-white' : 'bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <select
            value={sort}
            onChange={e => setSort(e.target.value)}
            className="shrink-0 text-[14px] font-semibold text-black bg-[#f6f6f3] border-none rounded-full px-4 py-2 outline-none cursor-pointer"
          >
            {SORT_OPTIONS.map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
      </section>

      {/* Grid */}
      <section className="py-10">
        <div className="max-w-[1280px] mx-auto px-6">
          {visible.length === 0 ? (
            <div className="text-center py-24">
              <div className="w-16 h-16 bg-[#f6f6f3] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
                </svg>
              </div>
              <h3 className="text-[18px] font-semibold text-black mb-2">No exhibitions found</h3>
              <p className="text-[14px] text-[#62625b]">Try adjusting your search or filters.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {visible.map(ex => (
                <button
                  key={ex.id}
                  onClick={() => navigate('exhibition-detail')}
                  className="bg-white rounded-2xl overflow-hidden text-left border border-[#dadad3] hover:border-[#c8c8c1] hover:shadow-sm transition-all group"
                >
                  <div className="relative overflow-hidden bg-[#f6f6f3]" style={{ height: 200 }}>
                    <img src={ex.image} alt={ex.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute top-3 left-3 flex items-center gap-2">
                      <StatusBadge status={ex.status} />
                    </div>
                    <div className="absolute top-3 right-3">
                      <span className="bg-white/90 backdrop-blur-sm text-black text-[11px] font-bold px-2.5 py-1 rounded-full">
                        {ex.category}
                      </span>
                    </div>
                  </div>

                  <div className="p-5">
                    <h3 className="text-[16px] font-semibold text-black mb-1.5 line-clamp-2">{ex.title}</h3>
                    <p className="text-[13px] text-[#62625b] mb-2">{ex.faculty} · {ex.university}</p>
                    <p className="text-[13px] text-[#91918c] mb-4 line-clamp-2">{ex.desc}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-[12px] text-[#91918c]">{ex.dates}</span>
                      <span className="text-[13px] font-semibold text-[#62625b]">{ex.projects} projects</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-10">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="w-10 h-10 rounded-full flex items-center justify-center bg-[#f6f6f3] text-black hover:bg-[#e5e5e0] disabled:opacity-30 transition-colors"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M15 18l-6-6 6-6" />
                </svg>
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(n => (
                <button
                  key={n}
                  onClick={() => setCurrentPage(n)}
                  className={`w-10 h-10 rounded-full text-[14px] font-semibold transition-colors ${
                    n === currentPage ? 'bg-black text-white' : 'bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]'
                  }`}
                >
                  {n}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="w-10 h-10 rounded-full flex items-center justify-center bg-[#f6f6f3] text-black hover:bg-[#e5e5e0] disabled:opacity-30 transition-colors"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 18l6-6-6-6" />
                </svg>
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
