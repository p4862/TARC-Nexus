import type { NavigateFn } from '../types'

const STATS = [
  { label: "Projects Submitted", value: "3", change: "+1 this month", icon: "◫", color: "bg-[#e60023]/8 text-[#e60023]" },
  { label: "Total Views", value: "1,284", change: "+312 this week", icon: "👁", color: "bg-blue-50 text-blue-600" },
  { label: "Downloads", value: "47", change: "+8 this week", icon: "⬇", color: "bg-emerald-50 text-emerald-600" },
  { label: "Exhibiting In", value: "2", change: "active exhibitions", icon: "🏛", color: "bg-purple-50 text-purple-600" },
]

const PROJECTS = [
  {
    id: 1,
    title: "Smart Vertical Farming System with IoT-Driven Microclimate Control",
    exhibition: "Innovations in Sustainable Technology",
    status: "Approved",
    updated: "2 days ago",
    views: 1284,
    image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=120&h=120&fit=crop&auto=format",
  },
  {
    id: 2,
    title: "AI-Powered Sign Language Translator for Deaf Communities",
    exhibition: "Data Science & AI Applications",
    status: "Pending Review",
    updated: "5 days ago",
    views: 0,
    image: "https://images.unsplash.com/photo-1767244489692-a047c63a463e?w=120&h=120&fit=crop&auto=format",
  },
  {
    id: 3,
    title: "Modular Earthquake-Resistant Housing System",
    exhibition: "Architecture & Urban Design 2025",
    status: "Draft",
    updated: "1 week ago",
    views: 0,
    image: "https://images.unsplash.com/photo-1655668135850-5eef0ba21f24?w=120&h=120&fit=crop&auto=format",
  },
]

const NOTIFICATIONS = [
  { id: 1, type: "approval", text: "Your project \"Smart Vertical Farming System\" has been approved.", time: "2 hours ago", read: false },
  { id: 2, type: "announcement", text: "Submissions are now open for Data Science & AI Applications.", time: "1 day ago", read: false },
  { id: 3, type: "update", text: "Architecture & Urban Design exhibition opens on 5 May 2025.", time: "3 days ago", read: true },
]

const QUICK_ACTIONS = [
  { label: "Submit New Project", icon: "+", color: "bg-[#e60023] text-white hover:bg-[#cc001f]", page: "submit" as const },
  { label: "Browse Exhibitions", icon: "⊞", color: "bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]", page: "exhibitions" as const },
  { label: "My Projects", icon: "◫", color: "bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]", page: "my-projects" as const },
]

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    Approved: 'bg-emerald-50 text-emerald-700',
    "Pending Review": 'bg-amber-50 text-amber-700',
    Draft: 'bg-[#f6f6f3] text-[#62625b]',
    Rejected: 'bg-red-50 text-red-700',
  }
  return <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${map[status] ?? 'bg-[#f6f6f3] text-[#62625b]'}`}>{status}</span>
}

const ACTIVITY_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
const ACTIVITY_VALUES = [42, 78, 55, 120, 89, 210, 180]
const MAX_VAL = Math.max(...ACTIVITY_VALUES)

export default function DashboardPage({ navigate }: { navigate: NavigateFn }) {
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  return (
    <div className="p-8 min-h-screen">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <p className="text-[#62625b] text-[14px] mb-1">{greeting}</p>
          <h1
            className="text-black font-bold"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(28px, 3vw, 38px)', letterSpacing: '-0.8px' }}
          >
            Ahmad Rizki
          </h1>
        </div>
        <button
          onClick={() => navigate('submit')}
          className="bg-[#e60023] text-white text-[14px] font-bold px-5 py-2.5 rounded-2xl hover:bg-[#cc001f] transition-colors flex items-center gap-2"
        >
          <span className="text-[18px] leading-none">+</span>
          Submit Project
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
        {STATS.map(stat => (
          <div key={stat.label} className="bg-white rounded-2xl border border-[#dadad3] p-5">
            <div className="flex items-center justify-between mb-3">
              <span className={`w-9 h-9 rounded-2xl flex items-center justify-center text-[16px] ${stat.color}`}>
                {stat.icon}
              </span>
            </div>
            <p
              className="text-black font-bold mb-1"
              style={{ fontFamily: "'Fraunces', serif", fontSize: 32, letterSpacing: '-0.5px', lineHeight: 1 }}
            >
              {stat.value}
            </p>
            <p className="text-[13px] font-medium text-[#62625b]">{stat.label}</p>
            <p className="text-[11px] text-[#91918c] mt-1">{stat.change}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6 mb-8">
        {/* Activity chart */}
        <div className="bg-white rounded-2xl border border-[#dadad3] p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-[16px] font-semibold text-black">Views This Week</h2>
            <span className="text-[13px] font-semibold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">+34%</span>
          </div>
          <div className="flex items-end gap-3 h-28">
            {ACTIVITY_DAYS.map((day, i) => (
              <div key={day} className="flex-1 flex flex-col items-center gap-2">
                <div
                  className="w-full rounded-xl transition-all"
                  style={{
                    height: `${(ACTIVITY_VALUES[i] / MAX_VAL) * 100}%`,
                    backgroundColor: i === 6 ? '#e60023' : '#f6f6f3',
                    minHeight: 8,
                  }}
                />
                <span className="text-[11px] text-[#91918c] font-medium">{day}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-6 mt-6 pt-4 border-t border-[#dadad3]">
            <div>
              <p className="text-[12px] text-[#91918c]">Total this week</p>
              <p className="text-[18px] font-bold text-black">774 views</p>
            </div>
            <div>
              <p className="text-[12px] text-[#91918c]">Peak day</p>
              <p className="text-[18px] font-bold text-black">Saturday</p>
            </div>
            <div>
              <p className="text-[12px] text-[#91918c]">Avg / day</p>
              <p className="text-[18px] font-bold text-black">110 views</p>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-2xl border border-[#dadad3] p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[16px] font-semibold text-black">Notifications</h2>
            <button
              onClick={() => navigate('notifications')}
              className="text-[12px] font-semibold text-[#62625b] hover:text-black transition-colors"
            >
              View all
            </button>
          </div>
          <div className="flex flex-col gap-3">
            {NOTIFICATIONS.map(n => (
              <div key={n.id} className="flex gap-3">
                <div className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${n.read ? 'bg-[#dadad3]' : 'bg-[#e60023]'}`} />
                <div>
                  <p className={`text-[13px] leading-snug ${n.read ? 'text-[#62625b]' : 'text-black font-medium'}`}>{n.text}</p>
                  <p className="text-[11px] text-[#91918c] mt-1">{n.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent projects */}
      <div className="bg-white rounded-2xl border border-[#dadad3] p-6 mb-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-[16px] font-semibold text-black">My Projects</h2>
          <button
            onClick={() => navigate('my-projects')}
            className="text-[12px] font-semibold text-[#62625b] hover:text-black transition-colors"
          >
            View all
          </button>
        </div>

        <div className="flex flex-col gap-3">
          {PROJECTS.map(project => (
            <div
              key={project.id}
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-[#fbfbf9] transition-colors"
            >
              <div className="w-14 h-14 rounded-2xl overflow-hidden bg-[#f6f6f3] shrink-0">
                <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[14px] font-semibold text-black line-clamp-1">{project.title}</p>
                <p className="text-[12px] text-[#62625b] mt-0.5">{project.exhibition}</p>
              </div>
              <div className="hidden md:flex items-center gap-3 shrink-0">
                <StatusBadge status={project.status} />
                <span className="text-[12px] text-[#91918c] w-24 text-right">{project.updated}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => navigate('project-detail')}
                  className="text-[12px] font-semibold text-[#62625b] bg-[#f6f6f3] px-3 py-1.5 rounded-full hover:bg-[#e5e5e0] transition-colors"
                >
                  View
                </button>
                <button
                  onClick={() => navigate('submit')}
                  className="text-[12px] font-semibold text-black bg-[#f6f6f3] px-3 py-1.5 rounded-full hover:bg-[#e5e5e0] transition-colors"
                >
                  Edit
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-[14px] font-semibold text-[#62625b] mb-3">Quick Actions</h2>
        <div className="flex gap-3 flex-wrap">
          {QUICK_ACTIONS.map(action => (
            <button
              key={action.label}
              onClick={() => navigate(action.page)}
              className={`flex items-center gap-2 text-[14px] font-semibold px-5 py-2.5 rounded-2xl transition-colors ${action.color}`}
            >
              <span>{action.icon}</span>
              {action.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
