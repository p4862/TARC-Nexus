import { useState, useRef } from 'react'
import type { NavigateFn } from '../types'

const STEPS = ['Basic Info', 'Description', 'Team', 'Media', 'Review']

const EXHIBITIONS = [
  "Innovations in Sustainable Technology",
  "Digital Arts & Creative Computing",
  "Data Science & AI Applications",
  "Architecture & Urban Design 2025",
  "Social Innovation Challenge",
  "Mechatronics & Robotics Expo",
]

const CATEGORIES = ["Technology", "Design", "Science", "Arts", "Engineering", "Business", "Medicine", "Architecture"]

interface TeamMember { name: string; email: string; role: string }
interface Link { label: string; url: string }

export default function SubmitProjectPage({ navigate }: { navigate: NavigateFn }) {
  const [step, setStep] = useState(0)
  const [submitted, setSubmitted] = useState(false)

  // Form state
  const [title, setTitle] = useState('')
  const [exhibition, setExhibition] = useState('')
  const [category, setCategory] = useState('')
  const [faculty, setFaculty] = useState('')
  const [abstract, setAbstract] = useState('')
  const [objectives, setObjectives] = useState('')
  const [keywords, setKeywords] = useState('')
  const [team, setTeam] = useState<TeamMember[]>([{ name: '', email: '', role: '' }])
  const [supervisor, setSupervisor] = useState({ name: '', email: '', dept: '' })
  const [coverImage, setCoverImage] = useState<string | null>(null)
  const [additionalImages, setAdditionalImages] = useState<string[]>([])
  const [videoUrl, setVideoUrl] = useState('')
  const [links, setLinks] = useState<Link[]>([{ label: '', url: '' }])
  const [docs, setDocs] = useState<string[]>([])
  const coverRef = useRef<HTMLInputElement>(null)

  const canProceed = [
    title.trim() && exhibition && category && faculty.trim(),
    abstract.trim() && objectives.trim(),
    team[0].name.trim() && supervisor.name.trim(),
    true,
    true,
  ][step]

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) setCoverImage(URL.createObjectURL(file))
  }

  const handleDocUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    setDocs(prev => [...prev, ...files.map(f => f.name)])
  }

  const addTeamMember = () => setTeam(t => [...t, { name: '', email: '', role: '' }])
  const removeTeamMember = (i: number) => setTeam(t => t.filter((_, idx) => idx !== i))
  const updateTeamMember = (i: number, field: keyof TeamMember, value: string) =>
    setTeam(t => t.map((m, idx) => idx === i ? { ...m, [field]: value } : m))

  const addLink = () => setLinks(l => [...l, { label: '', url: '' }])
  const updateLink = (i: number, field: keyof Link, value: string) =>
    setLinks(l => l.map((lk, idx) => idx === i ? { ...lk, [field]: value } : lk))

  if (submitted) {
    return (
      <div className="flex items-center justify-center min-h-screen p-8">
        <div className="text-center max-w-[480px]">
          <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>
          <h1
            className="text-black font-bold mb-3"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 32, letterSpacing: '-0.8px' }}
          >
            Project Submitted!
          </h1>
          <p className="text-[#62625b] text-[15px] leading-relaxed mb-8">
            Your project has been submitted for review. You'll receive an email notification once it's approved by the exhibition organiser. This typically takes 2–5 business days.
          </p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={() => navigate('my-projects')}
              className="bg-[#e60023] text-white text-[14px] font-bold px-6 py-3 rounded-2xl hover:bg-[#cc001f] transition-colors"
            >
              View My Projects
            </button>
            <button
              onClick={() => navigate('dashboard')}
              className="bg-[#f6f6f3] text-black text-[14px] font-bold px-6 py-3 rounded-2xl hover:bg-[#e5e5e0] transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-8 max-w-[800px]">
      {/* Header */}
      <div className="mb-8">
        <p className="text-[#e60023] text-[12px] font-bold tracking-widest uppercase mb-2">Exhibitor Portal</p>
        <h1
          className="text-black font-bold mb-1"
          style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(26px, 3vw, 34px)', letterSpacing: '-0.8px' }}
        >
          Submit a Project
        </h1>
        <p className="text-[#62625b] text-[14px]">Complete all sections to submit your project for exhibition review.</p>
      </div>

      {/* Progress steps */}
      <div className="flex items-center gap-0 mb-10 overflow-x-auto pb-2">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-0 shrink-0">
            <button
              onClick={() => i < step && setStep(i)}
              className="flex items-center gap-2"
              disabled={i > step}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-[13px] font-bold transition-colors ${
                  i < step
                    ? 'bg-black text-white'
                    : i === step
                    ? 'bg-[#e60023] text-white'
                    : 'bg-[#f6f6f3] text-[#91918c]'
                }`}
              >
                {i < step ? (
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="2 6 5 9 10 3" />
                  </svg>
                ) : i + 1}
              </div>
              <span className={`text-[13px] font-semibold hidden sm:block ${
                i === step ? 'text-black' : i < step ? 'text-[#62625b]' : 'text-[#91918c]'
              }`}>
                {s}
              </span>
            </button>
            {i < STEPS.length - 1 && (
              <div className={`h-px w-8 sm:w-12 mx-2 ${i < step ? 'bg-black' : 'bg-[#dadad3]'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Step content */}
      <div className="bg-white rounded-[32px] border border-[#dadad3] p-8 mb-6">

        {/* Step 0: Basic Info */}
        {step === 0 && (
          <div className="flex flex-col gap-5">
            <h2 className="text-[20px] font-semibold text-black mb-1">Basic Information</h2>
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Project Title *</label>
              <input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Smart Vertical Farming System with IoT-Driven Microclimate Control"
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Exhibition *</label>
                <select
                  value={exhibition}
                  onChange={e => setExhibition(e.target.value)}
                  className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors bg-white"
                >
                  <option value="">Select exhibition</option>
                  {EXHIBITIONS.map(ex => <option key={ex}>{ex}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Category *</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors bg-white"
                >
                  <option value="">Select category</option>
                  {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Faculty / Department *</label>
              <input
                value={faculty}
                onChange={e => setFaculty(e.target.value)}
                placeholder="e.g. Faculty of Electrical Engineering"
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
              />
            </div>
          </div>
        )}

        {/* Step 1: Description */}
        {step === 1 && (
          <div className="flex flex-col gap-5">
            <h2 className="text-[20px] font-semibold text-black mb-1">Project Description</h2>
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">
                Abstract * <span className="text-[#91918c] font-normal">({abstract.length}/800 characters)</span>
              </label>
              <textarea
                value={abstract}
                onChange={e => setAbstract(e.target.value.slice(0, 800))}
                rows={5}
                placeholder="Summarise your project's purpose, methodology, and findings in clear, accessible language..."
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors resize-none placeholder:text-[#91918c]"
              />
            </div>
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Objectives *</label>
              <textarea
                value={objectives}
                onChange={e => setObjectives(e.target.value)}
                rows={4}
                placeholder="List your project's primary objectives, one per line..."
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors resize-none placeholder:text-[#91918c]"
              />
            </div>
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Keywords</label>
              <input
                value={keywords}
                onChange={e => setKeywords(e.target.value)}
                placeholder="IoT, machine learning, hydroponics, sustainability (comma-separated)"
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
              />
            </div>
          </div>
        )}

        {/* Step 2: Team */}
        {step === 2 && (
          <div className="flex flex-col gap-6">
            <h2 className="text-[20px] font-semibold text-black mb-1">Team & Supervisor</h2>

            <div>
              <h3 className="text-[14px] font-semibold text-black mb-3">Team Members</h3>
              <div className="flex flex-col gap-3">
                {team.map((member, i) => (
                  <div key={i} className="p-4 bg-[#fbfbf9] rounded-2xl">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[13px] font-semibold text-[#62625b]">Member {i + 1}{i === 0 ? ' (Lead)' : ''}</span>
                      {i > 0 && (
                        <button onClick={() => removeTeamMember(i)} className="text-[12px] text-[#91918c] hover:text-[#e60023] transition-colors">
                          Remove
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {(['name', 'email', 'role'] as const).map(field => (
                        <input
                          key={field}
                          value={member[field]}
                          onChange={e => updateTeamMember(i, field, e.target.value)}
                          placeholder={field === 'name' ? 'Full name' : field === 'email' ? 'Email address' : 'Role / contribution'}
                          className="border border-[#dadad3] rounded-2xl px-3 py-2.5 text-[14px] text-black outline-none focus:border-black transition-colors bg-white placeholder:text-[#91918c]"
                        />
                      ))}
                    </div>
                  </div>
                ))}
                <button
                  onClick={addTeamMember}
                  className="flex items-center gap-2 text-[13px] font-semibold text-[#62625b] hover:text-black transition-colors py-2"
                >
                  <span className="w-6 h-6 rounded-full bg-[#f6f6f3] flex items-center justify-center text-[16px] leading-none">+</span>
                  Add team member
                </button>
              </div>
            </div>

            <div>
              <h3 className="text-[14px] font-semibold text-black mb-3">Supervisor *</h3>
              <div className="p-4 bg-[#fbfbf9] rounded-2xl">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['name', 'email', 'dept'] as const).map(field => (
                    <input
                      key={field}
                      value={supervisor[field]}
                      onChange={e => setSupervisor(s => ({ ...s, [field]: e.target.value }))}
                      placeholder={field === 'name' ? 'Supervisor name' : field === 'email' ? 'Institutional email' : 'Department'}
                      className="border border-[#dadad3] rounded-2xl px-3 py-2.5 text-[14px] text-black outline-none focus:border-black transition-colors bg-white placeholder:text-[#91918c]"
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Media */}
        {step === 3 && (
          <div className="flex flex-col gap-6">
            <h2 className="text-[20px] font-semibold text-black mb-1">Media & Documents</h2>

            {/* Cover image */}
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-2">Cover Image</label>
              <button
                onClick={() => coverRef.current?.click()}
                className="w-full border-2 border-dashed border-[#dadad3] rounded-2xl p-8 hover:border-black transition-colors flex flex-col items-center justify-center gap-3 text-center"
                style={{ minHeight: coverImage ? 'auto' : 160 }}
              >
                {coverImage ? (
                  <img src={coverImage} alt="Cover" className="w-full max-h-48 object-cover rounded-2xl" />
                ) : (
                  <>
                    <div className="w-12 h-12 bg-[#f6f6f3] rounded-full flex items-center justify-center">
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-[14px] font-semibold text-black">Upload cover image</p>
                      <p className="text-[12px] text-[#91918c]">PNG, JPG up to 10 MB. Recommended: 1280×720px</p>
                    </div>
                  </>
                )}
              </button>
              <input ref={coverRef} type="file" accept="image/*" onChange={handleCoverUpload} className="hidden" />
            </div>

            {/* Video URL */}
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Video URL (optional)</label>
              <input
                value={videoUrl}
                onChange={e => setVideoUrl(e.target.value)}
                placeholder="https://youtube.com/watch?v=..."
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
              />
            </div>

            {/* Document uploads */}
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-2">Documents</label>
              <label className="w-full border-2 border-dashed border-[#dadad3] rounded-2xl p-6 hover:border-black transition-colors flex items-center justify-center gap-3 cursor-pointer">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" />
                </svg>
                <span className="text-[14px] font-semibold text-[#62625b]">Upload PDF, ZIP, or DOCX</span>
                <input type="file" accept=".pdf,.zip,.docx" multiple onChange={handleDocUpload} className="hidden" />
              </label>
              {docs.length > 0 && (
                <div className="flex flex-col gap-2 mt-3">
                  {docs.map((doc, i) => (
                    <div key={i} className="flex items-center gap-3 bg-[#f6f6f3] rounded-2xl px-4 py-2.5">
                      <span className="text-[13px] text-black font-medium flex-1">{doc}</span>
                      <button onClick={() => setDocs(d => d.filter((_, j) => j !== i))} className="text-[#91918c] hover:text-[#e60023] transition-colors text-[16px]">×</button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* External links */}
            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-2">External Links</label>
              <div className="flex flex-col gap-2">
                {links.map((lk, i) => (
                  <div key={i} className="grid grid-cols-2 gap-2">
                    <input
                      value={lk.label}
                      onChange={e => updateLink(i, 'label', e.target.value)}
                      placeholder="Label (e.g. GitHub)"
                      className="border border-[#dadad3] rounded-2xl px-3 py-2.5 text-[14px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
                    />
                    <input
                      value={lk.url}
                      onChange={e => updateLink(i, 'url', e.target.value)}
                      placeholder="https://..."
                      className="border border-[#dadad3] rounded-2xl px-3 py-2.5 text-[14px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
                    />
                  </div>
                ))}
                <button
                  onClick={addLink}
                  className="flex items-center gap-2 text-[13px] font-semibold text-[#62625b] hover:text-black transition-colors py-1"
                >
                  <span className="w-5 h-5 rounded-full bg-[#f6f6f3] flex items-center justify-center text-[14px] leading-none">+</span>
                  Add another link
                </button>
              </div>
            </div>

            {additionalImages.length > 0 && <div className="text-[13px] text-[#62625b]">{additionalImages.length} additional images added.</div>}
          </div>
        )}

        {/* Step 4: Review */}
        {step === 4 && (
          <div className="flex flex-col gap-5">
            <h2 className="text-[20px] font-semibold text-black mb-1">Review & Submit</h2>
            <p className="text-[14px] text-[#62625b]">Please review your project details before submitting.</p>

            {[
              { label: "Project Title", value: title || '—' },
              { label: "Exhibition", value: exhibition || '—' },
              { label: "Category", value: category || '—' },
              { label: "Faculty", value: faculty || '—' },
              { label: "Abstract", value: abstract ? abstract.slice(0, 120) + (abstract.length > 120 ? '…' : '') : '—' },
              { label: "Team Lead", value: team[0]?.name || '—' },
              { label: "Supervisor", value: supervisor.name || '—' },
              { label: "Documents", value: docs.length ? `${docs.length} file${docs.length > 1 ? 's' : ''}` : 'None' },
              { label: "Cover Image", value: coverImage ? 'Uploaded' : 'Not uploaded' },
            ].map(row => (
              <div key={row.label} className="flex items-start gap-4 py-3 border-b border-[#f6f6f3]">
                <span className="text-[13px] font-semibold text-[#91918c] w-36 shrink-0">{row.label}</span>
                <span className="text-[14px] text-black">{row.value}</span>
              </div>
            ))}

            <div className="mt-4 p-4 bg-amber-50 rounded-2xl">
              <p className="text-[13px] text-amber-800 font-medium">
                After submission, your project will be reviewed by the exhibition organiser. You'll be notified of the outcome within 2–5 business days.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Navigation buttons */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex gap-3">
          {step > 0 && (
            <button
              onClick={() => setStep(s => s - 1)}
              className="bg-[#f6f6f3] text-black text-[14px] font-bold px-6 py-3 rounded-2xl hover:bg-[#e5e5e0] transition-colors"
            >
              ← Back
            </button>
          )}
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => navigate('dashboard')}
            className="bg-[#f6f6f3] text-[#62625b] text-[14px] font-semibold px-6 py-3 rounded-2xl hover:bg-[#e5e5e0] transition-colors"
          >
            Save Draft
          </button>
          {step < STEPS.length - 1 ? (
            <button
              onClick={() => canProceed && setStep(s => s + 1)}
              disabled={!canProceed}
              className="bg-[#e60023] text-white text-[14px] font-bold px-6 py-3 rounded-2xl hover:bg-[#cc001f] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Continue →
            </button>
          ) : (
            <button
              onClick={() => setSubmitted(true)}
              className="bg-[#e60023] text-white text-[14px] font-bold px-8 py-3 rounded-2xl hover:bg-[#cc001f] transition-colors"
            >
              Submit Project
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
