import { useState } from 'react'
import type { NavigateFn } from '../types'

interface LoginPageProps {
  navigate: NavigateFn
  onLoginSuccess: () => void
}

export default function LoginPage({ navigate, onLoginSuccess }: LoginPageProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [institution, setInstitution] = useState('')
  const [remember, setRemember] = useState(false)
  const [agreeTerms, setAgreeTerms] = useState(false)
  const [loading, setLoading] = useState(false)

  const passwordStrength = password.length === 0 ? 0 : password.length < 6 ? 1 : password.length < 10 ? 2 : 3
  const strengthLabels = ['', 'Weak', 'Fair', 'Strong']
  const strengthColors = ['', 'bg-[#e60023]', 'bg-amber-400', 'bg-emerald-500']

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => { setLoading(false); onLoginSuccess() }, 1200)
  }

  return (
    <div className="min-h-screen flex">
      {/* Left panel — image */}
      <div className="hidden lg:block flex-1 relative overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1553644446-9f8f2762ea42?w=1200&h=1400&fit=crop&auto=format"
          alt="Gallery"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-black/30 to-transparent" />
        <div className="absolute bottom-12 left-10 right-10">
          <div className="flex items-center gap-2 mb-5">
            <div className="w-7 h-7 bg-[#e60023] rounded-full flex items-center justify-center">
              <svg width="12" height="12" viewBox="0 0 14 14" fill="white">
                <path d="M7 0C3.13 0 0 3.13 0 7c0 2.97 1.84 5.52 4.46 6.59-.06-.52-.12-1.33.02-1.9.13-.51.87-3.7.87-3.7s-.22-.44-.22-1.1c0-1.03.6-1.8 1.34-1.8.63 0 .94.47.94 1.04 0 .63-.4 1.58-.61 2.46-.17.73.37 1.33 1.09 1.33 1.3 0 2.31-1.38 2.31-3.37 0-1.76-1.26-2.99-3.07-2.99-2.09 0-3.31 1.57-3.31 3.19 0 .63.24 1.31.54 1.68.06.07.07.13.05.2-.06.22-.18.73-.2.83-.03.13-.1.16-.23.1-.87-.41-1.41-1.68-1.41-2.71 0-2.2 1.6-4.23 4.62-4.23 2.42 0 4.31 1.73 4.31 4.03 0 2.41-1.52 4.34-3.62 4.34-.71 0-1.37-.37-1.6-.8l-.43 1.62c-.16.6-.58 1.35-.86 1.81.65.2 1.34.31 2.05.31 3.87 0 7-3.13 7-7S10.87 0 7 0z" />
              </svg>
            </div>
            <span className="text-white font-bold text-[14px]">ExhibitHub</span>
          </div>
          <blockquote
            className="text-white font-bold leading-tight mb-3"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(22px, 2.5vw, 30px)', letterSpacing: '-0.5px' }}
          >
            "Showcase your work to an audience that matters."
          </blockquote>
          <p className="text-white/60 text-[14px]">Join 2,840 students and researchers already exhibiting on the platform.</p>
          <div className="flex items-center gap-4 mt-6">
            {[
              { value: "142", label: "Active Exhibitions" },
              { value: "48", label: "Universities" },
              { value: "95K+", label: "Monthly Visitors" },
            ].map(s => (
              <div key={s.label} className="bg-white/10 backdrop-blur-sm rounded-2xl px-4 py-3">
                <p className="text-white font-bold text-[18px]">{s.value}</p>
                <p className="text-white/60 text-[11px]">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 lg:max-w-[520px] flex flex-col justify-center px-8 md:px-14 py-12 bg-white">
        <div className="max-w-[400px] mx-auto w-full">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-7 h-7 bg-[#e60023] rounded-full flex items-center justify-center">
              <svg width="12" height="12" viewBox="0 0 14 14" fill="white">
                <path d="M7 0C3.13 0 0 3.13 0 7c0 2.97 1.84 5.52 4.46 6.59-.06-.52-.12-1.33.02-1.9.13-.51.87-3.7.87-3.7s-.22-.44-.22-1.1c0-1.03.6-1.8 1.34-1.8.63 0 .94.47.94 1.04 0 .63-.4 1.58-.61 2.46-.17.73.37 1.33 1.09 1.33 1.3 0 2.31-1.38 2.31-3.37 0-1.76-1.26-2.99-3.07-2.99-2.09 0-3.31 1.57-3.31 3.19 0 .63.24 1.31.54 1.68.06.07.07.13.05.2-.06.22-.18.73-.2.83-.03.13-.1.16-.23.1-.87-.41-1.41-1.68-1.41-2.71 0-2.2 1.6-4.23 4.62-4.23 2.42 0 4.31 1.73 4.31 4.03 0 2.41-1.52 4.34-3.62 4.34-.71 0-1.37-.37-1.6-.8l-.43 1.62c-.16.6-.58 1.35-.86 1.81.65.2 1.34.31 2.05.31 3.87 0 7-3.13 7-7S10.87 0 7 0z" />
              </svg>
            </div>
            <span className="font-bold text-black">ExhibitHub</span>
          </div>

          <h1
            className="text-black font-bold mb-1"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 32, letterSpacing: '-0.8px' }}
          >
            {mode === 'login' ? 'Welcome back' : 'Create an account'}
          </h1>
          <p className="text-[#62625b] text-[15px] mb-8">
            {mode === 'login'
              ? 'Sign in to your ExhibitHub account.'
              : 'Register to submit and showcase your projects.'}
          </p>

          {/* Mode toggle */}
          <div className="flex items-center bg-[#f6f6f3] rounded-2xl p-1 mb-8">
            {(['login', 'register'] as const).map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 text-[14px] font-semibold py-2 rounded-xl transition-all ${
                  mode === m ? 'bg-white text-black shadow-sm' : 'text-[#62625b] hover:text-black'
                }`}
              >
                {m === 'login' ? 'Log in' : 'Register'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {mode === 'register' && (
              <>
                <div>
                  <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Full name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="Ahmad Rizki bin Hamdan"
                    required
                    className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
                  />
                </div>
                <div>
                  <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Institution</label>
                  <input
                    type="text"
                    value={institution}
                    onChange={e => setInstitution(e.target.value)}
                    placeholder="Universiti Teknologi Malaysia"
                    required
                    className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-[12px] font-semibold text-[#62625b] mb-1.5">Email address</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@university.edu"
                required
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[12px] font-semibold text-[#62625b]">Password</label>
                {mode === 'login' && (
                  <button type="button" className="text-[12px] font-semibold text-[#211922] hover:text-[#e60023] transition-colors">
                    Forgot password?
                  </button>
                )}
              </div>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full border border-[#dadad3] rounded-2xl px-4 py-3 text-[15px] text-black outline-none focus:border-black transition-colors placeholder:text-[#91918c]"
              />
              {mode === 'register' && password.length > 0 && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3].map(level => (
                      <div
                        key={level}
                        className={`h-1 flex-1 rounded-full transition-colors ${
                          level <= passwordStrength ? strengthColors[passwordStrength] : 'bg-[#dadad3]'
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-[11px] text-[#62625b]">{strengthLabels[passwordStrength]} password</p>
                </div>
              )}
            </div>

            {mode === 'login' ? (
              <label className="flex items-center gap-3 cursor-pointer">
                <div
                  onClick={() => setRemember(r => !r)}
                  className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-colors cursor-pointer ${
                    remember ? 'bg-black border-black' : 'border-[#dadad3]'
                  }`}
                >
                  {remember && (
                    <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="2 6 5 9 10 3" />
                    </svg>
                  )}
                </div>
                <span className="text-[14px] text-[#33332e]">Remember me for 30 days</span>
              </label>
            ) : (
              <label className="flex items-start gap-3 cursor-pointer">
                <div
                  onClick={() => setAgreeTerms(a => !a)}
                  className={`mt-0.5 w-5 h-5 shrink-0 rounded-md border-2 flex items-center justify-center transition-colors cursor-pointer ${
                    agreeTerms ? 'bg-black border-black' : 'border-[#dadad3]'
                  }`}
                >
                  {agreeTerms && (
                    <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="2 6 5 9 10 3" />
                    </svg>
                  )}
                </div>
                <span className="text-[14px] text-[#33332e]">
                  I agree to the{' '}
                  <a href="#" className="text-[#211922] font-semibold underline underline-offset-2">Terms of Service</a>
                  {' '}and{' '}
                  <a href="#" className="text-[#211922] font-semibold underline underline-offset-2">Privacy Policy</a>
                </span>
              </label>
            )}

            <button
              type="submit"
              disabled={loading || (mode === 'register' && !agreeTerms)}
              className="w-full bg-[#e60023] text-white text-[14px] font-bold rounded-2xl py-3.5 hover:bg-[#cc001f] disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2 mt-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                  </svg>
                  Signing in…
                </>
              ) : mode === 'login' ? 'Log in to ExhibitHub' : 'Create my account'}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-[#dadad3] text-center">
            <p className="text-[14px] text-[#62625b]">
              {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
              <button
                onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
                className="font-semibold text-black hover:text-[#e60023] transition-colors"
              >
                {mode === 'login' ? 'Register free' : 'Log in'}
              </button>
            </p>
          </div>

          <p className="text-center text-[12px] text-[#91918c] mt-4">
            <button onClick={() => navigate('home')} className="hover:text-black transition-colors">
              ← Back to ExhibitHub
            </button>
          </p>
        </div>
      </div>
    </div>
  )
}
