import { useState } from 'react'
import type { NavigateFn } from '../types'

const EXHIBITIONS = [
  {
    id: 1,
    title: "Innovations in Sustainable Technology",
    faculty: "Faculty of Engineering",
    dates: "15 Mar – 30 Apr 2025",
    projects: 24,
    status: "Active",
    image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=600&h=400&fit=crop&auto=format",
    category: "Technology",
  },
  {
    id: 2,
    title: "Digital Arts & Creative Computing",
    faculty: "School of Design",
    dates: "1 Feb – 28 Feb 2025",
    projects: 18,
    status: "Active",
    image: "https://images.unsplash.com/photo-1769913775153-0468a774d9ff?w=600&h=400&fit=crop&auto=format",
    category: "Arts",
  },
  {
    id: 3,
    title: "Data Science & AI Applications",
    faculty: "Faculty of Computing",
    dates: "1 Apr – 30 Apr 2025",
    projects: 28,
    status: "Active",
    image: "https://images.unsplash.com/photo-1768655317930-23e7cd2d336e?w=600&h=400&fit=crop&auto=format",
    category: "Technology",
  },
]

const PROJECTS = [
  {
    id: 1,
    title: "Smart Vertical Farming System",
    author: "Ahmad Rizki",
    category: "IoT & Sustainability",
    image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=400&h=520&fit=crop&auto=format",
    aspect: "3/4",
  },
  {
    id: 2,
    title: "AI Sign Language Translator",
    author: "Nurul Hana",
    category: "Machine Learning",
    image: "https://images.unsplash.com/photo-1767244489692-a047c63a463e?w=400&h=400&fit=crop&auto=format",
    aspect: "1/1",
  },
  {
    id: 3,
    title: "Regenerative Textile System",
    author: "Lim Wei Chen",
    category: "Sustainable Design",
    image: "https://images.unsplash.com/photo-1769913775153-0468a774d9ff?w=400&h=560&fit=crop&auto=format",
    aspect: "5/7",
  },
  {
    id: 4,
    title: "Neural Interface for Rehab",
    author: "Priya Sharma",
    category: "Biomedical AI",
    image: "https://images.unsplash.com/photo-1582719299076-dd3f6f970dd4?w=400&h=400&fit=crop&auto=format",
    aspect: "1/1",
  },
  {
    id: 5,
    title: "Real-time Air Quality Monitor",
    author: "Tan Jia Wei",
    category: "Environmental IoT",
    image: "https://images.unsplash.com/photo-1646756089735-487709743361?w=400&h=480&fit=crop&auto=format",
    aspect: "5/6",
  },
  {
    id: 6,
    title: "Modular Quake-Resistant Housing",
    author: "Arif Budiman",
    category: "Architecture",
    image: "https://images.unsplash.com/photo-1655668135850-5eef0ba21f24?w=400&h=560&fit=crop&auto=format",
    aspect: "5/7",
  },
  {
    id: 7,
    title: "Predictive Healthcare Analytics",
    author: "Mei Ling Tan",
    category: "Data Science",
    image: "https://images.unsplash.com/photo-1581094271901-8022df4466f9?w=400&h=480&fit=crop&auto=format",
    aspect: "5/6",
  },
  {
    id: 8,
    title: "Decentralised Energy Grid",
    author: "Ravi Kumar",
    category: "Clean Energy",
    image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=400&h=360&fit=crop&auto=format",
    aspect: "9/8",
  },
]

const CATEGORIES = ["Technology", "Design", "Science", "Arts", "Engineering", "Business", "Medicine", "Architecture"]

const STATS = [
  { value: "142", label: "Active Exhibitions" },
  { value: "2,840", label: "Projects Showcased" },
  { value: "48", label: "Universities" },
  { value: "95K+", label: "Monthly Visitors" },
]

const STEPS = [
  {
    number: "01",
    title: "Register as an Exhibitor",
    body: "Create your account using your institutional email. Verification takes less than 24 hours.",
    image: "https://images.unsplash.com/photo-1596495717678-69df9f89c2a3?w=600&h=700&fit=crop&auto=format",
  },
  {
    number: "02",
    title: "Submit Your Project",
    body: "Fill in your project details, upload images and documents, add your team members and supervisor.",
    image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=600&h=700&fit=crop&auto=format",
  },
  {
    number: "03",
    title: "Get Discovered Globally",
    body: "Your approved project is visible to industry partners, academics, and visitors worldwide.",
    image: "https://images.unsplash.com/photo-1768655317930-23e7cd2d336e?w=600&h=700&fit=crop&auto=format",
  },
]

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    Active: 'bg-emerald-50 text-emerald-700',
    Upcoming: 'bg-blue-50 text-blue-700',
    Past: 'bg-[#f6f6f3] text-[#62625b]',
  }
  return (
    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${styles[status] ?? styles.Past}`}>
      {status}
    </span>
  )
}

function ExhibitionCard({ ex, navigate }: { ex: typeof EXHIBITIONS[0]; navigate: NavigateFn }) {
  return (
    <button
      onClick={() => navigate('exhibition-detail')}
      className="bg-white rounded-2xl overflow-hidden text-left group border border-[#dadad3] hover:border-[#c8c8c1] transition-all"
    >
      <div className="relative overflow-hidden bg-[#f6f6f3]" style={{ height: 200 }}>
        <img
          src={ex.image}
          alt={ex.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3">
          <StatusBadge status={ex.status} />
        </div>
        <div className="absolute top-3 right-3">
          <span className="bg-white/90 backdrop-blur-sm text-black text-[11px] font-bold px-2.5 py-1 rounded-full">
            {ex.category}
          </span>
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-[16px] font-semibold text-black mb-1 line-clamp-2">{ex.title}</h3>
        <p className="text-[13px] text-[#62625b] mb-3">{ex.faculty}</p>
        <div className="flex items-center justify-between">
          <span className="text-[12px] text-[#91918c]">{ex.dates}</span>
          <span className="text-[12px] font-semibold text-[#62625b]">{ex.projects} projects</span>
        </div>
      </div>
    </button>
  )
}

function ProjectCard({ project, navigate }: { project: typeof PROJECTS[0]; navigate: NavigateFn }) {
  return (
    <div className="masonry-item">
      <button
        onClick={() => navigate('project-detail')}
        className="pin-card w-full relative overflow-hidden rounded-2xl bg-[#f6f6f3] group block"
      >
        <div className="relative" style={{ aspectRatio: project.aspect }}>
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover"
          />
          <div className="pin-overlay absolute inset-0 bg-black/20 opacity-0 transition-opacity duration-200 flex flex-col justify-between p-3">
            <span className="self-start bg-white text-black text-[11px] font-bold px-2.5 py-1 rounded-full">
              {project.category}
            </span>
            <div className="text-left">
              <p className="text-white text-[13px] font-semibold leading-tight">{project.title}</p>
              <p className="text-white/70 text-[11px] mt-0.5">{project.author}</p>
            </div>
          </div>
        </div>
        <div className="px-3 py-2.5">
          <p className="text-[13px] font-semibold text-black line-clamp-2">{project.title}</p>
          <p className="text-[11px] text-[#62625b] mt-0.5">{project.author}</p>
        </div>
      </button>
    </div>
  )
}

export default function HomePage({ navigate }: { navigate: NavigateFn }) {
  const [activeCategory, setActiveCategory] = useState<string | null>(null)

  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="relative min-h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1627367601465-5196287d58aa?w=1600&h=900&fit=crop&auto=format"
            alt="Virtual exhibition gallery"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
        </div>

        <div className="relative z-10 max-w-[1280px] mx-auto px-6 py-20">
          <div className="max-w-[600px]">
            <div className="flex items-center gap-2 mb-6">
              <span className="bg-[#e60023] text-white text-[11px] font-bold px-3 py-1 rounded-full">
                NEW SEASON OPEN
              </span>
              <span className="text-white/70 text-[13px]">142 active exhibitions now accepting projects</span>
            </div>
            <h1
              className="text-white font-bold leading-[1.05] mb-6"
              style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(44px, 6vw, 70px)', letterSpacing: '-1.2px' }}
            >
              Discover exhibitions that inspire the next breakthrough
            </h1>
            <p className="text-white/75 text-[18px] leading-relaxed mb-8 max-w-[500px]">
              A platform where academic and professional projects meet a global audience. Browse, submit, and get discovered.
            </p>
            <div className="flex items-center gap-3 flex-wrap">
              <button
                onClick={() => navigate('exhibitions')}
                className="bg-[#e60023] text-white text-[14px] font-bold px-6 rounded-2xl hover:bg-[#cc001f] transition-colors flex items-center gap-2"
                style={{ height: 48 }}
              >
                Explore Exhibitions
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </button>
              <button
                onClick={() => navigate('login')}
                className="bg-white text-black text-[14px] font-bold px-6 rounded-2xl hover:bg-white/90 transition-colors"
                style={{ height: 48 }}
              >
                Submit a Project
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Category chips */}
      <section className="bg-white border-b border-[#dadad3] py-4 sticky top-16 z-30">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(activeCategory === cat ? null : cat)}
                className={`whitespace-nowrap text-[14px] font-semibold px-4 py-2 rounded-full transition-colors ${
                  activeCategory === cat
                    ? 'bg-black text-white'
                    : 'bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-[#fbfbf9] py-16 border-b border-[#dadad3]">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {STATS.map(s => (
              <div key={s.label} className="text-center">
                <p
                  className="font-bold text-black mb-1"
                  style={{ fontFamily: "'Fraunces', serif", fontSize: 48, letterSpacing: '-1px', lineHeight: 1 }}
                >
                  {s.value}
                </p>
                <p className="text-[#62625b] text-[14px] font-medium">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Exhibitions */}
      <section className="py-16">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="text-[#e60023] text-[12px] font-bold tracking-widest uppercase mb-2">Curated for You</p>
              <h2
                className="text-black font-bold"
                style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(28px, 3vw, 36px)', letterSpacing: '-1px' }}
              >
                Featured Exhibitions
              </h2>
            </div>
            <button
              onClick={() => navigate('exhibitions')}
              className="text-[14px] font-semibold text-black hover:text-[#e60023] transition-colors flex items-center gap-1"
            >
              View all
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {EXHIBITIONS.map(ex => (
              <ExhibitionCard key={ex.id} ex={ex} navigate={navigate} />
            ))}
          </div>
        </div>
      </section>

      {/* Project Masonry */}
      <section className="py-16 bg-[#f6f6f3]">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="text-[#e60023] text-[12px] font-bold tracking-widest uppercase mb-2">Student Work</p>
              <h2
                className="text-black font-bold"
                style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(28px, 3vw, 36px)', letterSpacing: '-1px' }}
              >
                Outstanding Projects
              </h2>
            </div>
            <button
              onClick={() => navigate('exhibitions')}
              className="text-[14px] font-semibold text-black hover:text-[#e60023] transition-colors flex items-center gap-1"
            >
              Explore all
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          <div className="masonry-grid">
            {PROJECTS.map(project => (
              <ProjectCard key={project.id} project={project} navigate={navigate} />
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-16 bg-white">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="text-center mb-14">
            <p className="text-[#e60023] text-[12px] font-bold tracking-widest uppercase mb-3">Simple Process</p>
            <h2
              className="text-black font-bold mx-auto"
              style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(28px, 3vw, 40px)', letterSpacing: '-1px', maxWidth: 560 }}
            >
              From idea to global audience in three steps
            </h2>
          </div>

          <div className="flex flex-col gap-8">
            {STEPS.map((step, i) => (
              <div
                key={step.number}
                className={`flex flex-col md:flex-row items-center gap-10 ${i % 2 === 1 ? 'md:flex-row-reverse' : ''}`}
              >
                <div className="flex-1">
                  <span
                    className="block text-[#e60023] font-bold mb-4"
                    style={{ fontFamily: "'Fraunces', serif", fontSize: 56, opacity: 0.15, lineHeight: 1 }}
                  >
                    {step.number}
                  </span>
                  <h3
                    className="text-black font-bold mb-4"
                    style={{ fontFamily: "'Fraunces', serif", fontSize: 28, letterSpacing: '-0.5px' }}
                  >
                    {step.title}
                  </h3>
                  <p className="text-[#62625b] text-[16px] leading-relaxed max-w-[420px]">{step.body}</p>
                </div>
                <div className="flex-1 max-w-[480px] w-full">
                  <div className="rounded-[32px] overflow-hidden bg-[#f6f6f3]" style={{ aspectRatio: '6/5' }}>
                    <img
                      src={step.image}
                      alt={step.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Strip */}
      <section className="bg-[#262622] py-20 px-6">
        <div className="max-w-[760px] mx-auto text-center">
          <h2
            className="text-white font-bold mb-5"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(32px, 4vw, 48px)', letterSpacing: '-1px' }}
          >
            Ready to showcase your work to the world?
          </h2>
          <p className="text-white/60 text-[16px] mb-8 leading-relaxed">
            Join over 2,800 students and researchers who have already exhibited their projects on ExhibitHub.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <button
              onClick={() => navigate('login')}
              className="bg-[#e60023] text-white text-[14px] font-bold px-8 rounded-2xl hover:bg-[#cc001f] transition-colors"
              style={{ height: 48 }}
            >
              Get started — it's free
            </button>
            <button
              onClick={() => navigate('exhibitions')}
              className="bg-white/10 text-white text-[14px] font-bold px-8 rounded-2xl hover:bg-white/20 transition-colors"
              style={{ height: 48 }}
            >
              Browse exhibitions
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-[#dadad3] py-12">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
            {[
              { heading: "Explore", links: ["All Exhibitions", "Featured Projects", "Categories", "Universities"] },
              { heading: "Exhibitors", links: ["Register", "Submit Project", "Guidelines", "FAQ"] },
              { heading: "Platform", links: ["About ExhibitHub", "For Institutions", "API Access", "Pricing"] },
              { heading: "Support", links: ["Help Center", "Contact Us", "Privacy Policy", "Terms of Use"] },
            ].map(col => (
              <div key={col.heading}>
                <p className="text-[14px] font-bold text-black mb-3">{col.heading}</p>
                <ul className="flex flex-col gap-2">
                  {col.links.map(link => (
                    <li key={link}>
                      <a href="#" className="text-[14px] text-[#62625b] hover:text-black transition-colors">{link}</a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between border-t border-[#dadad3] pt-6">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-[#e60023] rounded-full flex items-center justify-center">
                <svg width="10" height="10" viewBox="0 0 14 14" fill="white">
                  <path d="M7 0C3.13 0 0 3.13 0 7c0 2.97 1.84 5.52 4.46 6.59-.06-.52-.12-1.33.02-1.9.13-.51.87-3.7.87-3.7s-.22-.44-.22-1.1c0-1.03.6-1.8 1.34-1.8.63 0 .94.47.94 1.04 0 .63-.4 1.58-.61 2.46-.17.73.37 1.33 1.09 1.33 1.3 0 2.31-1.38 2.31-3.37 0-1.76-1.26-2.99-3.07-2.99-2.09 0-3.31 1.57-3.31 3.19 0 .63.24 1.31.54 1.68.06.07.07.13.05.2-.06.22-.18.73-.2.83-.03.13-.1.16-.23.1-.87-.41-1.41-1.68-1.41-2.71 0-2.2 1.6-4.23 4.62-4.23 2.42 0 4.31 1.73 4.31 4.03 0 2.41-1.52 4.34-3.62 4.34-.71 0-1.37-.37-1.6-.8l-.43 1.62c-.16.6-.58 1.35-.86 1.81.65.2 1.34.31 2.05.31 3.87 0 7-3.13 7-7S10.87 0 7 0z" />
                </svg>
              </div>
              <span className="text-[13px] font-bold text-black">ExhibitHub</span>
            </div>
            <p className="text-[12px] text-[#91918c]">© 2025 ExhibitHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
