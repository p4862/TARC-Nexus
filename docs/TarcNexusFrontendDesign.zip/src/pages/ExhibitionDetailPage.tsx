import { useState } from 'react'
import type { NavigateFn } from '../types'

const EXHIBITION = {
  title: "Innovations in Sustainable Technology",
  faculty: "Faculty of Engineering",
  university: "Universiti Teknologi Malaysia",
  organizer: "Prof. Dr. Azman bin Abdullah",
  status: "Active",
  category: "Technology",
  startDate: "15 March 2025",
  endDate: "30 April 2025",
  submissionDeadline: "1 March 2025",
  location: "Virtual — Open to the Public",
  projectCount: 24,
  viewCount: "4,820",
  description: "The Innovations in Sustainable Technology exhibition brings together the brightest engineering and technology students to present solutions that address the United Nations Sustainable Development Goals. From renewable energy and smart agriculture to waste management and water purification, this exhibition is a testament to the power of student-driven innovation.\n\nThis year's edition features 24 projects across six thematic tracks: Clean Energy, Smart Cities, Sustainable Agriculture, Circular Economy, Climate Adaptation, and Green Manufacturing.",
  tracks: ["Clean Energy", "Smart Cities", "Sustainable Agriculture", "Circular Economy", "Climate Adaptation", "Green Manufacturing"],
}

const PROJECTS = [
  { id: 1, title: "Smart Vertical Farming System", author: "Ahmad Rizki & Team", track: "Sustainable Agriculture", status: "Approved", image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=400&h=520&fit=crop&auto=format", aspect: "3/4" },
  { id: 2, title: "Solar-Powered Water Desalination Unit", author: "Lim Wei Chen", track: "Clean Energy", status: "Approved", image: "https://images.unsplash.com/photo-1582719299076-dd3f6f970dd4?w=400&h=400&fit=crop&auto=format", aspect: "1/1" },
  { id: 3, title: "AI-Driven Waste Sorting Robot", author: "Nurul Hana & Priya", track: "Circular Economy", status: "Approved", image: "https://images.unsplash.com/photo-1769913775153-0468a774d9ff?w=400&h=560&fit=crop&auto=format", aspect: "5/7" },
  { id: 4, title: "Real-time Urban Air Quality Monitor", author: "Tan Jia Wei", track: "Smart Cities", status: "Approved", image: "https://images.unsplash.com/photo-1646756089735-487709743361?w=400&h=480&fit=crop&auto=format", aspect: "5/6" },
  { id: 5, title: "Biochar Carbon Capture System", author: "Ravi Kumar", track: "Climate Adaptation", status: "Approved", image: "https://images.unsplash.com/photo-1768655317930-23e7cd2d336e?w=400&h=480&fit=crop&auto=format", aspect: "5/6" },
  { id: 6, title: "Modular Micro-Wind Turbine Array", author: "Arif Budiman & Team", track: "Clean Energy", status: "Approved", image: "https://images.unsplash.com/photo-1655668135850-5eef0ba21f24?w=400&h=560&fit=crop&auto=format", aspect: "5/7" },
  { id: 7, title: "Mycelium Composite Construction", author: "Mei Ling Tan", track: "Green Manufacturing", status: "Approved", image: "https://images.unsplash.com/photo-1581094271901-8022df4466f9?w=400&h=400&fit=crop&auto=format", aspect: "1/1" },
  { id: 8, title: "Smart Irrigation Mesh Network", author: "Zulaikha Othman", track: "Sustainable Agriculture", status: "Pending", image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=400&h=360&fit=crop&auto=format", aspect: "9/8" },
]

const FILTERS = ["All Tracks", "Clean Energy", "Smart Cities", "Sustainable Agriculture", "Circular Economy", "Climate Adaptation", "Green Manufacturing"]

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    Approved: 'bg-emerald-50 text-emerald-700',
    Pending: 'bg-amber-50 text-amber-700',
    Active: 'bg-emerald-50 text-emerald-700',
  }
  return <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${map[status] ?? 'bg-[#f6f6f3] text-[#62625b]'}`}>{status}</span>
}

export default function ExhibitionDetailPage({ navigate }: { navigate: NavigateFn }) {
  const [activeFilter, setActiveFilter] = useState('All Tracks')
  const [projectQuery, setProjectQuery] = useState('')

  const visibleProjects = PROJECTS.filter(p => {
    const matchTrack = activeFilter === 'All Tracks' || p.track === activeFilter
    const matchQ = !projectQuery || p.title.toLowerCase().includes(projectQuery.toLowerCase())
    return matchTrack && matchQ
  })

  return (
    <div className="pt-16">
      {/* Banner */}
      <section className="relative overflow-hidden bg-black" style={{ height: 440 }}>
        <img
          src="https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=1600&h=600&fit=crop&auto=format"
          alt={EXHIBITION.title}
          className="w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 px-6 pb-10 max-w-[1280px] mx-auto">
          <div className="flex items-center gap-2 mb-3">
            <StatusBadge status={EXHIBITION.status} />
            <span className="bg-white/20 text-white text-[11px] font-bold px-2.5 py-1 rounded-full">{EXHIBITION.category}</span>
          </div>
          <h1
            className="text-white font-bold mb-3"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(28px, 4vw, 48px)', letterSpacing: '-1px', maxWidth: 700 }}
          >
            {EXHIBITION.title}
          </h1>
          <p className="text-white/70 text-[15px]">
            {EXHIBITION.faculty} · {EXHIBITION.university}
          </p>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="max-w-[1280px] mx-auto px-6 py-4">
        <div className="flex items-center gap-2 text-[13px] text-[#62625b]">
          <button onClick={() => navigate('home')} className="hover:text-black transition-colors">Home</button>
          <span>›</span>
          <button onClick={() => navigate('exhibitions')} className="hover:text-black transition-colors">Exhibitions</button>
          <span>›</span>
          <span className="text-black font-medium line-clamp-1" style={{ maxWidth: 300 }}>{EXHIBITION.title}</span>
        </div>
      </div>

      {/* Content */}
      <section className="max-w-[1280px] mx-auto px-6 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-10">
          {/* Left: description */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-1.5 bg-[#f6f6f3] rounded-full px-3 py-1.5">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#62625b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
                <span className="text-[13px] font-semibold text-[#62625b]">{EXHIBITION.projectCount} projects</span>
              </div>
              <div className="flex items-center gap-1.5 bg-[#f6f6f3] rounded-full px-3 py-1.5">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#62625b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
                </svg>
                <span className="text-[13px] font-semibold text-[#62625b]">{EXHIBITION.viewCount} views</span>
              </div>
            </div>

            <h2 className="text-[20px] font-semibold text-black mb-4">About this Exhibition</h2>
            {EXHIBITION.description.split('\n\n').map((para, i) => (
              <p key={i} className="text-[15px] text-[#33332e] leading-relaxed mb-4">{para}</p>
            ))}

            <h3 className="text-[16px] font-semibold text-black mt-6 mb-3">Thematic Tracks</h3>
            <div className="flex flex-wrap gap-2">
              {EXHIBITION.tracks.map(track => (
                <span key={track} className="bg-[#f6f6f3] text-black text-[13px] font-medium px-3 py-1.5 rounded-full">{track}</span>
              ))}
            </div>
          </div>

          {/* Right sidebar */}
          <div className="space-y-4">
            <div className="bg-white rounded-[32px] border border-[#dadad3] p-6">
              <h3 className="text-[16px] font-semibold text-black mb-4">Exhibition Details</h3>
              <dl className="flex flex-col gap-3">
                {[
                  { label: "Organiser", value: EXHIBITION.organizer },
                  { label: "Start date", value: EXHIBITION.startDate },
                  { label: "End date", value: EXHIBITION.endDate },
                  { label: "Submission deadline", value: EXHIBITION.submissionDeadline },
                  { label: "Location", value: EXHIBITION.location },
                ].map(item => (
                  <div key={item.label}>
                    <dt className="text-[11px] font-bold text-[#91918c] uppercase tracking-wide">{item.label}</dt>
                    <dd className="text-[14px] text-black font-medium mt-0.5">{item.value}</dd>
                  </div>
                ))}
              </dl>
              <button
                onClick={() => navigate('login')}
                className="mt-6 w-full bg-[#e60023] text-white text-[14px] font-bold py-3 rounded-2xl hover:bg-[#cc001f] transition-colors"
              >
                Submit a Project
              </button>
            </div>

            <div className="bg-white rounded-[32px] border border-[#dadad3] p-6">
              <h3 className="text-[15px] font-semibold text-black mb-3">Share</h3>
              <div className="flex gap-2">
                {["Twitter", "LinkedIn", "Email"].map(platform => (
                  <button key={platform} className="flex-1 bg-[#f6f6f3] text-black text-[12px] font-semibold py-2 rounded-2xl hover:bg-[#e5e5e0] transition-colors">
                    {platform}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Projects section */}
        <div className="mt-14">
          <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
            <div className="flex-1">
              <h2
                className="text-black font-bold"
                style={{ fontFamily: "'Fraunces', serif", fontSize: 28, letterSpacing: '-0.5px' }}
              >
                {EXHIBITION.projectCount} Projects
              </h2>
            </div>
            <div className="flex items-center bg-[#f6f6f3] rounded-full px-4 gap-3 md:w-[300px]" style={{ height: 44 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#91918c" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
              <input
                value={projectQuery}
                onChange={e => setProjectQuery(e.target.value)}
                placeholder="Search projects..."
                className="flex-1 bg-transparent text-[14px] text-black outline-none placeholder:text-[#91918c]"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto mb-6 pb-1" style={{ scrollbarWidth: 'none' }}>
            {FILTERS.map(f => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`whitespace-nowrap text-[13px] font-semibold px-4 py-2 rounded-full transition-colors ${
                  activeFilter === f ? 'bg-black text-white' : 'bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          <div className="masonry-grid">
            {visibleProjects.map(project => (
              <div key={project.id} className="masonry-item">
                <button
                  onClick={() => navigate('project-detail')}
                  className="pin-card w-full relative overflow-hidden rounded-2xl bg-[#f6f6f3] group block text-left"
                >
                  <div className="relative" style={{ aspectRatio: project.aspect }}>
                    <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
                    <div className="pin-overlay absolute inset-0 bg-black/20 opacity-0 transition-opacity duration-200 flex flex-col justify-between p-3">
                      <span className="self-start bg-white text-black text-[11px] font-bold px-2.5 py-1 rounded-full">
                        {project.track}
                      </span>
                    </div>
                  </div>
                  <div className="px-3 py-2.5">
                    <p className="text-[13px] font-semibold text-black line-clamp-2">{project.title}</p>
                    <p className="text-[11px] text-[#62625b] mt-0.5">{project.author}</p>
                  </div>
                </button>
              </div>
            ))}
          </div>

          {visibleProjects.length === 0 && (
            <div className="text-center py-20">
              <p className="text-[#62625b] text-[15px]">No projects match your search.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
