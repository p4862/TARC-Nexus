import type { NavigateFn } from '../types'

export default function NotFoundPage({ navigate }: { navigate: NavigateFn }) {
  return (
    <div className="min-h-screen bg-[#fbfbf9] flex items-center justify-center px-6">
      <div className="text-center max-w-[520px]">
        <p
          className="font-bold text-[#e60023] mb-4"
          style={{ fontFamily: "'Fraunces', serif", fontSize: 120, lineHeight: 1, letterSpacing: '-4px', opacity: 0.12 }}
        >
          404
        </p>
        <h1
          className="text-black font-bold mb-4 -mt-6"
          style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(28px, 4vw, 40px)', letterSpacing: '-1px' }}
        >
          Page not found
        </h1>
        <p className="text-[#62625b] text-[16px] leading-relaxed mb-8">
          The exhibition or project you're looking for doesn't exist, has been removed, or the link may have expired.
        </p>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <button
            onClick={() => navigate('home')}
            className="bg-[#e60023] text-white text-[14px] font-bold px-6 py-3 rounded-2xl hover:bg-[#cc001f] transition-colors"
          >
            Back to home
          </button>
          <button
            onClick={() => navigate('exhibitions')}
            className="bg-[#f6f6f3] text-black text-[14px] font-bold px-6 py-3 rounded-2xl hover:bg-[#e5e5e0] transition-colors"
          >
            Browse exhibitions
          </button>
        </div>
      </div>
    </div>
  )
}
