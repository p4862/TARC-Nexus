import { useState } from 'react'
import type { NavigateFn } from '../types'

const PROJECT = {
  title: "Smart Vertical Farming System with IoT-Driven Microclimate Control",
  exhibition: "Innovations in Sustainable Technology",
  faculty: "Faculty of Engineering",
  university: "Universiti Teknologi Malaysia",
  category: "Sustainable Agriculture",
  year: 2025,
  views: 1284,
  downloads: 47,
  abstract: "This project presents a fully autonomous vertical farming unit that combines IoT sensor arrays, machine learning crop prediction, and closed-loop hydroponics to reduce water consumption by 94% compared to conventional agriculture. The system monitors temperature, humidity, CO₂, pH, EC, and light spectra in real time, automatically adjusting actuators to maintain optimal microclimate conditions for each crop layer. A React Native companion app provides live telemetry and yield forecasting for farm operators.",
  objectives: [
    "Design and prototype a modular vertical farming rack suitable for urban environments.",
    "Develop an IoT sensor mesh that collects 8 environmental parameters at 1-minute intervals.",
    "Train a LSTM model on 6 months of crop yield data to predict harvest timing within ±2 days.",
    "Achieve at least 90% water savings versus open-field cultivation through closed-loop hydroponics.",
    "Validate the system in a controlled pilot deployment over a 12-week growing cycle.",
  ],
  technologies: ["React Native", "Node.js", "TensorFlow Lite", "MQTT", "InfluxDB", "ESP32", "Arduino", "Raspberry Pi 4", "Python", "Docker"],
  team: [
    { name: "Ahmad Rizki bin Hamdan", role: "Lead Engineer & IoT Developer", avatar: "AR" },
    { name: "Nurul Hana binti Yusof", role: "Machine Learning Engineer", avatar: "NH" },
    { name: "Tan Jia Wei", role: "Backend Systems & DevOps", avatar: "TJ" },
    { name: "Priya Sharma", role: "UI/UX & Mobile Development", avatar: "PS" },
  ],
  supervisor: { name: "Prof. Dr. Azman bin Abdullah", dept: "Dept. of Electrical Engineering", email: "azman@utm.edu.my" },
  documents: [
    { name: "Full Technical Report", size: "4.2 MB", type: "PDF" },
    { name: "Project Poster (A0)", size: "8.1 MB", type: "PDF" },
    { name: "Dataset (CSV)", size: "1.8 MB", type: "ZIP" },
    { name: "Source Code", size: "2.3 MB", type: "ZIP" },
  ],
  links: [
    { label: "GitHub Repository", url: "#" },
    { label: "Live Demo", url: "#" },
    { label: "Video Presentation", url: "#" },
  ],
  gallery: [
    { src: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?w=800&h=600&fit=crop&auto=format", caption: "IoT sensor array and control board" },
    { src: "https://images.unsplash.com/photo-1768655317930-23e7cd2d336e?w=800&h=600&fit=crop&auto=format", caption: "Vertical rack prototype — Layer 3" },
    { src: "https://images.unsplash.com/photo-1769913775153-0468a774d9ff?w=800&h=600&fit=crop&auto=format", caption: "LED grow-light spectrum analysis" },
    { src: "https://images.unsplash.com/photo-1646756089735-487709743361?w=800&h=600&fit=crop&auto=format", caption: "Mobile dashboard — live telemetry" },
  ],
}

const RELATED = [
  { title: "Biochar Carbon Capture System", author: "Ravi Kumar", image: "https://images.unsplash.com/photo-1655668135850-5eef0ba21f24?w=400&h=500&fit=crop&auto=format" },
  { title: "Solar-Powered Desalination Unit", author: "Lim Wei Chen", image: "https://images.unsplash.com/photo-1582719299076-dd3f6f970dd4?w=400&h=500&fit=crop&auto=format" },
  { title: "Smart Irrigation Mesh Network", author: "Zulaikha Othman", image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=400&h=500&fit=crop&auto=format" },
]

const AVATAR_COLORS = ["bg-[#e60023]", "bg-[#6845ab]", "bg-[#103c25]", "bg-[#435ee5]"]

export default function ProjectDetailPage({ navigate }: { navigate: NavigateFn }) {
  const [activeGallery, setActiveGallery] = useState(0)
  const [saved, setSaved] = useState(false)

  return (
    <div className="pt-16">
      {/* Hero image */}
      <section className="relative overflow-hidden bg-black" style={{ height: 500 }}>
        <img
          src={PROJECT.gallery[activeGallery].src}
          alt={PROJECT.title}
          className="w-full h-full object-cover opacity-70 transition-all duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

        {/* Gallery thumbnails */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
          {PROJECT.gallery.map((img, i) => (
            <button
              key={i}
              onClick={() => setActiveGallery(i)}
              className={`w-12 h-12 rounded-2xl overflow-hidden border-2 transition-all ${
                i === activeGallery ? 'border-white scale-110' : 'border-white/40 opacity-60 hover:opacity-80'
              }`}
            >
              <img src={img.src} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>

        {/* Title overlay */}
        <div className="absolute bottom-20 left-0 right-0 max-w-[1280px] mx-auto px-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="bg-white/20 backdrop-blur-sm text-white text-[11px] font-bold px-2.5 py-1 rounded-full">
              {PROJECT.category}
            </span>
            <span className="bg-white/20 backdrop-blur-sm text-white text-[11px] font-bold px-2.5 py-1 rounded-full">
              {PROJECT.year}
            </span>
          </div>
          <h1
            className="text-white font-bold"
            style={{ fontFamily: "'Fraunces', serif", fontSize: 'clamp(24px, 3.5vw, 40px)', letterSpacing: '-0.8px', maxWidth: 760 }}
          >
            {PROJECT.title}
          </h1>
        </div>
      </section>

      {/* Breadcrumb + actions */}
      <div className="max-w-[1280px] mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2 text-[13px] text-[#62625b]">
          <button onClick={() => navigate('home')} className="hover:text-black transition-colors">Home</button>
          <span>›</span>
          <button onClick={() => navigate('exhibition-detail')} className="hover:text-black transition-colors">{PROJECT.exhibition}</button>
          <span>›</span>
          <span className="text-black font-medium hidden md:block" style={{ maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{PROJECT.title}</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSaved(s => !s)}
            className={`flex items-center gap-2 text-[13px] font-semibold px-4 py-2 rounded-full transition-colors ${
              saved ? 'bg-black text-white' : 'bg-[#f6f6f3] text-black hover:bg-[#e5e5e0]'
            }`}
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill={saved ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
            </svg>
            {saved ? 'Saved' : 'Save'}
          </button>
          <button className="flex items-center gap-2 text-[13px] font-semibold bg-[#f6f6f3] text-black px-4 py-2 rounded-full hover:bg-[#e5e5e0] transition-colors">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" />
              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" /><line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
            </svg>
            Share
          </button>
        </div>
      </div>

      {/* Main content */}
      <section className="max-w-[1280px] mx-auto px-6 pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-10">

          {/* Left column */}
          <div>
            {/* Stats row */}
            <div className="flex items-center gap-4 mb-8">
              {[
                { icon: "👁", label: `${PROJECT.views.toLocaleString()} views` },
                { icon: "⬇", label: `${PROJECT.downloads} downloads` },
                { icon: "🎓", label: PROJECT.faculty },
              ].map(s => (
                <span key={s.label} className="text-[13px] text-[#62625b] flex items-center gap-1.5">
                  <span>{s.icon}</span>{s.label}
                </span>
              ))}
            </div>

            {/* Abstract */}
            <div className="mb-8">
              <h2 className="text-[20px] font-semibold text-black mb-4">Abstract</h2>
              <p className="text-[15px] text-[#33332e] leading-[1.7]">{PROJECT.abstract}</p>
            </div>

            {/* Objectives */}
            <div className="mb-8">
              <h2 className="text-[20px] font-semibold text-black mb-4">Objectives</h2>
              <ol className="flex flex-col gap-3">
                {PROJECT.objectives.map((obj, i) => (
                  <li key={i} className="flex gap-4 text-[15px] text-[#33332e] leading-relaxed">
                    <span
                      className="shrink-0 w-6 h-6 rounded-full bg-[#e60023] text-white text-[11px] font-bold flex items-center justify-center mt-0.5"
                    >
                      {i + 1}
                    </span>
                    {obj}
                  </li>
                ))}
              </ol>
            </div>

            {/* Technologies */}
            <div className="mb-8">
              <h2 className="text-[20px] font-semibold text-black mb-4">Technologies Used</h2>
              <div className="flex flex-wrap gap-2">
                {PROJECT.technologies.map(tech => (
                  <span key={tech} className="bg-[#f6f6f3] text-black text-[13px] font-semibold px-3 py-1.5 rounded-full">
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Gallery */}
            <div className="mb-8">
              <h2 className="text-[20px] font-semibold text-black mb-4">Gallery</h2>
              <div className="grid grid-cols-2 gap-3">
                {PROJECT.gallery.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveGallery(i)}
                    className={`relative overflow-hidden rounded-2xl bg-[#f6f6f3] ${i === 0 ? 'col-span-2' : ''} transition-all`}
                    style={{ aspectRatio: i === 0 ? '16/7' : '4/3' }}
                  >
                    <img src={img.src} alt={img.caption} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                      <p className="text-white text-[12px]">{img.caption}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Related Projects */}
            <div>
              <h2 className="text-[20px] font-semibold text-black mb-4">Related Projects</h2>
              <div className="grid grid-cols-3 gap-3">
                {RELATED.map(p => (
                  <button
                    key={p.title}
                    onClick={() => navigate('project-detail')}
                    className="text-left group"
                  >
                    <div className="rounded-2xl overflow-hidden bg-[#f6f6f3] mb-2" style={{ aspectRatio: '4/5' }}>
                      <img src={p.image} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <p className="text-[13px] font-semibold text-black line-clamp-2">{p.title}</p>
                    <p className="text-[11px] text-[#62625b] mt-0.5">{p.author}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right sidebar */}
          <div className="space-y-4">
            {/* Team */}
            <div className="bg-white rounded-[32px] border border-[#dadad3] p-6">
              <h3 className="text-[16px] font-semibold text-black mb-4">Team Members</h3>
              <div className="flex flex-col gap-3">
                {PROJECT.team.map((member, i) => (
                  <div key={member.name} className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-full ${AVATAR_COLORS[i]} flex items-center justify-center text-white text-[12px] font-bold shrink-0`}>
                      {member.avatar}
                    </div>
                    <div>
                      <p className="text-[13px] font-semibold text-black leading-tight">{member.name}</p>
                      <p className="text-[11px] text-[#62625b]">{member.role}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Supervisor */}
            <div className="bg-white rounded-[32px] border border-[#dadad3] p-6">
              <h3 className="text-[16px] font-semibold text-black mb-3">Supervisor</h3>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#262622] flex items-center justify-center text-white text-[12px] font-bold shrink-0">
                  AA
                </div>
                <div>
                  <p className="text-[13px] font-semibold text-black">{PROJECT.supervisor.name}</p>
                  <p className="text-[11px] text-[#62625b]">{PROJECT.supervisor.dept}</p>
                  <a href={`mailto:${PROJECT.supervisor.email}`} className="text-[11px] text-[#e60023] font-medium">{PROJECT.supervisor.email}</a>
                </div>
              </div>
            </div>

            {/* Exhibition */}
            <div className="bg-white rounded-[32px] border border-[#dadad3] p-6">
              <h3 className="text-[15px] font-semibold text-black mb-2">Part of Exhibition</h3>
              <button
                onClick={() => navigate('exhibition-detail')}
                className="text-[13px] text-[#e60023] font-semibold hover:underline text-left"
              >
                {PROJECT.exhibition}
              </button>
              <p className="text-[12px] text-[#91918c] mt-1">{PROJECT.university}</p>
            </div>

            {/* Downloads */}
            <div className="bg-white rounded-[32px] border border-[#dadad3] p-6">
              <h3 className="text-[16px] font-semibold text-black mb-4">Downloads</h3>
              <div className="flex flex-col gap-2">
                {PROJECT.documents.map(doc => (
                  <button
                    key={doc.name}
                    className="flex items-center justify-between p-3 rounded-2xl bg-[#f6f6f3] hover:bg-[#e5e5e0] transition-colors text-left"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-[#e60023]/10 rounded-xl flex items-center justify-center">
                        <span className="text-[10px] font-bold text-[#e60023]">{doc.type}</span>
                      </div>
                      <div>
                        <p className="text-[13px] font-semibold text-black leading-tight">{doc.name}</p>
                        <p className="text-[11px] text-[#91918c]">{doc.size}</p>
                      </div>
                    </div>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#62625b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
                    </svg>
                  </button>
                ))}
              </div>
            </div>

            {/* External Links */}
            <div className="bg-white rounded-[32px] border border-[#dadad3] p-6">
              <h3 className="text-[16px] font-semibold text-black mb-3">External Links</h3>
              <div className="flex flex-col gap-2">
                {PROJECT.links.map(link => (
                  <a
                    key={link.label}
                    href={link.url}
                    className="flex items-center justify-between text-[13px] font-medium text-black hover:text-[#e60023] transition-colors py-1"
                  >
                    {link.label}
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
                    </svg>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
