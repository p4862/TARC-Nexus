# Figma Make Prompt – Virtual Exhibition System UI/UX

I am designing a **Virtual Exhibition System** that will be developed using **React** for the frontend and **Laravel** for the backend.

I have attached a **design specification document (`design.md`)**. **Treat this document as the primary source of truth for the application's design system, branding, colour palette, typography, spacing, components, layout rules, user flows, and functional requirements.** Follow it closely and ensure every screen is consistent with the design language defined in the document. If there is any conflict between this prompt and `design.md`, prioritise `design.md`.

## Objective

Create a modern, professional, responsive, and visually appealing UI mockup for the complete Virtual Exhibition System. The design should feel clean, elegant, and suitable for showcasing academic, student, or professional exhibition projects.

The UI should be suitable for implementation using React components and should follow good UX practices, including:

* Consistent spacing and layout
* Reusable UI components
* Responsive desktop-first design with mobile adaptability
* Accessibility considerations
* Clear navigation hierarchy
* Modern card-based layouts where appropriate
* Clean typography and readable content
* Consistent button, form, and input styles

---

## Required Screens

Design high-fidelity mockups for the following modules.

### 1. Landing / Home Page

Include sections such as:

* Hero section
* Call-to-action buttons
* Featured exhibitions
* Featured projects
* About the platform
* Benefits/features
* Statistics
* Testimonials (optional)
* Footer
* Navigation bar

The homepage should encourage visitors to explore exhibitions and register as exhibitors.

---

### 2. Exhibition Listing Page

Include:

* Search bar
* Category filters
* Exhibition cards
* Status badges
* Pagination or infinite scrolling
* Sorting options

---

### 3. Exhibition Details Page

Display:

* Exhibition banner
* Description
* Exhibition information
* Participating projects
* Search/filter projects
* Gallery or preview images
* Call-to-action to explore projects

---

### 4. Project Details Page

Include:

* Large project cover image
* Gallery
* Project title
* Student/exhibitor information
* Abstract
* Objectives
* Technologies used
* Supervisor information
* Downloadable documents
* External links (if applicable)
* Related projects

---

### 5. Login Page (Exhibitor)

Design:

* Login form
* Forgot password
* Remember me
* Register button
* Clean authentication layout

---

### 6. Registration Page

Include:

* Full registration form
* Validation-friendly layout
* Password strength indicator
* Terms and conditions checkbox
* Success call-to-action

---

### 7. Exhibitor Dashboard

Display:

* Welcome section
* Dashboard summary cards
* Submitted projects
* Submission status
* Notifications
* Quick actions
* Profile shortcut

---

### 8. Submit Project Page

Design a multi-section form for project submission.

Possible sections include:

* Basic Information
* Project Description
* Team Members
* Supervisor
* Categories
* Keywords
* Upload Images
* Upload Documents
* Upload Video
* External Links
* Save Draft
* Submit Project

The form should feel intuitive and easy to complete.

---

### 9. Edit Project Page

Provide an editable version of the submission form with:

* Existing uploaded files
* Preview functionality
* Version update support
* Save changes button

---

### 10. Profile Management

Include:

* Personal information
* Profile picture
* Contact information
* Change password
* Social links
* Academic information (if applicable)

---

### 11. My Projects Page

Display:

* Project cards
* Submission progress
* Status indicators
* Edit button
* View button
* Delete confirmation

---

### 12. Notifications Page

Include:

* Submission updates
* Approval status
* System announcements
* Read/unread states

---

### 13. Search Results Page

Provide:

* Search input
* Filters
* Sort options
* Matching projects
* Matching exhibitions
* Empty state

---

### 14. Error & Empty States

Design:

* 404 page
* Empty search results
* No exhibitions available
* No submitted projects
* Upload failure state

---

## Components

Create reusable components including:

* Navigation bar
* Footer
* Cards
* Buttons
* Inputs
* Dropdowns
* Tabs
* Modals
* Toast notifications
* Tables
* Pagination
* Breadcrumbs
* Status badges
* Tags
* Search bars
* File upload components
* Image gallery
* User avatar
* Sidebar navigation

---

## Visual Style

The overall design should be:

* Modern
* Minimalist
* Professional
* Elegant
* Clean
* Academic and portfolio-oriented
* Easy to navigate
* Consistent across all pages

Avoid cluttered layouts and prioritise readability and usability.

---

## Design System

Create a consistent design system including:

* Colour palette
* Typography hierarchy
* Buttons
* Form controls
* Icons
* Spacing scale
* Grid system
* Shadows
* Border radius
* Cards
* Component variants

All pages should reuse these components consistently.

---

## Deliverables

Generate:

* High-fidelity desktop mockups
* Responsive layouts where appropriate
* Consistent reusable components
* Auto Layout-enabled frames
* Well-organised layers and naming
* Production-ready UI suitable for implementation in React

The final result should represent a polished, scalable Virtual Exhibition System that aligns closely with the attached `design.md` specification and is ready to be translated into frontend components and backend functionality.
