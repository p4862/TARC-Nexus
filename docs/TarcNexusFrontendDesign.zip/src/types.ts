export type Page =
  | 'home'
  | 'exhibitions'
  | 'exhibition-detail'
  | 'project-detail'
  | 'login'
  | 'dashboard'
  | 'submit'
  | 'my-projects'
  | 'profile'
  | 'notifications'
  | 'search'
  | 'not-found'

export type NavigateFn = (page: Page) => void
